﻿
namespace Market
{
    partial class FrmProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ProductID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CategoryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SupplierID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PurchasePrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SalePrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Barcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IsActive = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSabt = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblSupplier = new System.Windows.Forms.Label();
            this.lblBarcode = new System.Windows.Forms.Label();
            this.lblKharid = new System.Windows.Forms.Label();
            this.lblForoosh = new System.Windows.Forms.Label();
            this.lblVahed = new System.Windows.Forms.Label();
            this.lblTozihat = new System.Windows.Forms.Label();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.txtCategory = new System.Windows.Forms.TextBox();
            this.txtSupplier = new System.Windows.Forms.TextBox();
            this.txtBarcode = new System.Windows.Forms.TextBox();
            this.txtKharid = new System.Windows.Forms.TextBox();
            this.txtForoosh = new System.Windows.Forms.TextBox();
            this.txtVahed = new System.Windows.Forms.TextBox();
            this.txtTozihat = new System.Windows.Forms.TextBox();
            this.rdbActive = new System.Windows.Forms.RadioButton();
            this.rdbNotActive = new System.Windows.Forms.RadioButton();
            this.lblForooshgah = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txtKala = new System.Windows.Forms.TextBox();
            this.btnBazgasht = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductID,
            this.ProductName,
            this.CategoryID,
            this.SupplierID,
            this.PurchasePrice,
            this.SalePrice,
            this.Unit,
            this.Barcode,
            this.Description,
            this.IsActive});
            this.dataGridView1.Location = new System.Drawing.Point(13, 292);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(812, 326);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // ProductID
            // 
            this.ProductID.DataPropertyName = "ProductID";
            this.ProductID.HeaderText = "کد";
            this.ProductID.Name = "ProductID";
            this.ProductID.Width = 40;
            // 
            // ProductName
            // 
            this.ProductName.DataPropertyName = "ProductName";
            this.ProductName.HeaderText = "نام محصول";
            this.ProductName.Name = "ProductName";
            // 
            // CategoryID
            // 
            this.CategoryID.DataPropertyName = "CategoryID";
            this.CategoryID.HeaderText = "کد دسته بندی";
            this.CategoryID.Name = "CategoryID";
            this.CategoryID.Width = 40;
            // 
            // SupplierID
            // 
            this.SupplierID.DataPropertyName = "SupplierID";
            this.SupplierID.HeaderText = "کد شزکت";
            this.SupplierID.Name = "SupplierID";
            this.SupplierID.Width = 40;
            // 
            // PurchasePrice
            // 
            this.PurchasePrice.DataPropertyName = "PurchasePrice";
            this.PurchasePrice.HeaderText = "قیمت خرید";
            this.PurchasePrice.Name = "PurchasePrice";
            // 
            // SalePrice
            // 
            this.SalePrice.DataPropertyName = "SalePrice";
            this.SalePrice.HeaderText = "قیمت فروش";
            this.SalePrice.Name = "SalePrice";
            // 
            // Unit
            // 
            this.Unit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Unit.DataPropertyName = "Unit";
            this.Unit.HeaderText = "واحد";
            this.Unit.Name = "Unit";
            this.Unit.Width = 51;
            // 
            // Barcode
            // 
            this.Barcode.DataPropertyName = "Barcode";
            this.Barcode.HeaderText = "بارکد";
            this.Barcode.Name = "Barcode";
            // 
            // Description
            // 
            this.Description.DataPropertyName = "Description";
            this.Description.HeaderText = "توضیحات";
            this.Description.Name = "Description";
            // 
            // IsActive
            // 
            this.IsActive.DataPropertyName = "IsActive";
            this.IsActive.HeaderText = "وضعیت";
            this.IsActive.Name = "IsActive";
            // 
            // btnSabt
            // 
            this.btnSabt.BackColor = System.Drawing.Color.LightGreen;
            this.btnSabt.Image = global::Market.Properties.Resources.add_item1;
            this.btnSabt.Location = new System.Drawing.Point(694, 137);
            this.btnSabt.Name = "btnSabt";
            this.btnSabt.Size = new System.Drawing.Size(121, 35);
            this.btnSabt.TabIndex = 4;
            this.btnSabt.Text = "ثبت";
            this.btnSabt.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnSabt.UseVisualStyleBackColor = false;
            this.btnSabt.Click += new System.EventHandler(this.btnSabt_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.SeaShell;
            this.btnEdit.Image = global::Market.Properties.Resources.edit_item1;
            this.btnEdit.Location = new System.Drawing.Point(694, 219);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(121, 35);
            this.btnEdit.TabIndex = 5;
            this.btnEdit.Text = "ویرایش";
            this.btnEdit.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Tomato;
            this.btnDelete.Image = global::Market.Properties.Resources.delete_item1;
            this.btnDelete.Location = new System.Drawing.Point(694, 178);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(121, 35);
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "حذف";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Image = global::Market.Properties.Resources.search_magnifier1;
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSearch.Location = new System.Drawing.Point(47, 231);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(506, 35);
            this.btnSearch.TabIndex = 7;
            this.btnSearch.Text = "جستجو";
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new System.Drawing.Point(44, 60);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(50, 18);
            this.lblProductName.TabIndex = 8;
            this.lblProductName.Text = "نام محصول";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(227, 60);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(61, 18);
            this.lblCategory.TabIndex = 9;
            this.lblCategory.Text = "کددسته بندی";
            // 
            // lblSupplier
            // 
            this.lblSupplier.AutoSize = true;
            this.lblSupplier.Location = new System.Drawing.Point(402, 60);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new System.Drawing.Size(42, 18);
            this.lblSupplier.TabIndex = 10;
            this.lblSupplier.Text = "کدشرکت";
            // 
            // lblBarcode
            // 
            this.lblBarcode.AutoSize = true;
            this.lblBarcode.Location = new System.Drawing.Point(526, 60);
            this.lblBarcode.Name = "lblBarcode";
            this.lblBarcode.Size = new System.Drawing.Size(27, 18);
            this.lblBarcode.TabIndex = 11;
            this.lblBarcode.Text = "بارکد";
            // 
            // lblKharid
            // 
            this.lblKharid.AutoSize = true;
            this.lblKharid.Location = new System.Drawing.Point(44, 154);
            this.lblKharid.Name = "lblKharid";
            this.lblKharid.Size = new System.Drawing.Size(52, 18);
            this.lblKharid.TabIndex = 12;
            this.lblKharid.Text = "قیمت خرید";
            // 
            // lblForoosh
            // 
            this.lblForoosh.AutoSize = true;
            this.lblForoosh.Location = new System.Drawing.Point(227, 154);
            this.lblForoosh.Name = "lblForoosh";
            this.lblForoosh.Size = new System.Drawing.Size(54, 18);
            this.lblForoosh.TabIndex = 13;
            this.lblForoosh.Text = "قیمت فروش";
            // 
            // lblVahed
            // 
            this.lblVahed.AutoSize = true;
            this.lblVahed.Location = new System.Drawing.Point(402, 154);
            this.lblVahed.Name = "lblVahed";
            this.lblVahed.Size = new System.Drawing.Size(26, 18);
            this.lblVahed.TabIndex = 14;
            this.lblVahed.Text = "واحد";
            // 
            // lblTozihat
            // 
            this.lblTozihat.AutoSize = true;
            this.lblTozihat.Location = new System.Drawing.Point(526, 154);
            this.lblTozihat.Name = "lblTozihat";
            this.lblTozihat.Size = new System.Drawing.Size(45, 18);
            this.lblTozihat.TabIndex = 15;
            this.lblTozihat.Text = "توضیحات";
            // 
            // txtProductName
            // 
            this.txtProductName.Location = new System.Drawing.Point(33, 82);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(173, 25);
            this.txtProductName.TabIndex = 16;
            // 
            // txtCategory
            // 
            this.txtCategory.Location = new System.Drawing.Point(212, 82);
            this.txtCategory.Name = "txtCategory";
            this.txtCategory.Size = new System.Drawing.Size(171, 25);
            this.txtCategory.TabIndex = 17;
            // 
            // txtSupplier
            // 
            this.txtSupplier.Location = new System.Drawing.Point(389, 82);
            this.txtSupplier.Name = "txtSupplier";
            this.txtSupplier.Size = new System.Drawing.Size(116, 25);
            this.txtSupplier.TabIndex = 18;
            // 
            // txtBarcode
            // 
            this.txtBarcode.Location = new System.Drawing.Point(511, 82);
            this.txtBarcode.Name = "txtBarcode";
            this.txtBarcode.Size = new System.Drawing.Size(160, 25);
            this.txtBarcode.TabIndex = 19;
            // 
            // txtKharid
            // 
            this.txtKharid.Location = new System.Drawing.Point(33, 175);
            this.txtKharid.Name = "txtKharid";
            this.txtKharid.Size = new System.Drawing.Size(173, 25);
            this.txtKharid.TabIndex = 20;
            // 
            // txtForoosh
            // 
            this.txtForoosh.Location = new System.Drawing.Point(212, 175);
            this.txtForoosh.Name = "txtForoosh";
            this.txtForoosh.Size = new System.Drawing.Size(171, 25);
            this.txtForoosh.TabIndex = 21;
            // 
            // txtVahed
            // 
            this.txtVahed.Location = new System.Drawing.Point(389, 175);
            this.txtVahed.Name = "txtVahed";
            this.txtVahed.Size = new System.Drawing.Size(116, 25);
            this.txtVahed.TabIndex = 22;
            // 
            // txtTozihat
            // 
            this.txtTozihat.Location = new System.Drawing.Point(511, 175);
            this.txtTozihat.Name = "txtTozihat";
            this.txtTozihat.Size = new System.Drawing.Size(160, 25);
            this.txtTozihat.TabIndex = 23;
            // 
            // rdbActive
            // 
            this.rdbActive.AutoSize = true;
            this.rdbActive.Location = new System.Drawing.Point(724, 63);
            this.rdbActive.Name = "rdbActive";
            this.rdbActive.Size = new System.Drawing.Size(51, 22);
            this.rdbActive.TabIndex = 24;
            this.rdbActive.TabStop = true;
            this.rdbActive.Text = "موجود";
            this.rdbActive.UseVisualStyleBackColor = true;
            // 
            // rdbNotActive
            // 
            this.rdbNotActive.AutoSize = true;
            this.rdbNotActive.Location = new System.Drawing.Point(724, 100);
            this.rdbNotActive.Name = "rdbNotActive";
            this.rdbNotActive.Size = new System.Drawing.Size(56, 22);
            this.rdbNotActive.TabIndex = 25;
            this.rdbNotActive.TabStop = true;
            this.rdbNotActive.Text = "ناموجود";
            this.rdbNotActive.UseVisualStyleBackColor = true;
            // 
            // lblForooshgah
            // 
            this.lblForooshgah.AutoSize = true;
            this.lblForooshgah.Font = new System.Drawing.Font("B Jadid", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblForooshgah.Location = new System.Drawing.Point(7, 9);
            this.lblForooshgah.Name = "lblForooshgah";
            this.lblForooshgah.Size = new System.Drawing.Size(111, 31);
            this.lblForooshgah.TabIndex = 26;
            this.lblForooshgah.Text = "هایپر آل سن";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(625, 14);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 25);
            this.dateTimePicker1.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 244);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 18);
            this.label1.TabIndex = 28;
            this.label1.Text = "نام کالا";
            // 
            // txtKala
            // 
            this.txtKala.Font = new System.Drawing.Font("B Nazanin", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtKala.Location = new System.Drawing.Point(158, 233);
            this.txtKala.Name = "txtKala";
            this.txtKala.Size = new System.Drawing.Size(299, 31);
            this.txtKala.TabIndex = 29;
            // 
            // btnBazgasht
            // 
            this.btnBazgasht.Location = new System.Drawing.Point(559, 233);
            this.btnBazgasht.Name = "btnBazgasht";
            this.btnBazgasht.Size = new System.Drawing.Size(112, 33);
            this.btnBazgasht.TabIndex = 30;
            this.btnBazgasht.Text = "بازگشت اطلاعات";
            this.btnBazgasht.UseVisualStyleBackColor = true;
            this.btnBazgasht.Click += new System.EventHandler(this.btnBazgasht_Click);
            // 
            // FrmProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(848, 623);
            this.Controls.Add(this.btnBazgasht);
            this.Controls.Add(this.txtKala);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblForooshgah);
            this.Controls.Add(this.rdbNotActive);
            this.Controls.Add(this.rdbActive);
            this.Controls.Add(this.txtTozihat);
            this.Controls.Add(this.txtVahed);
            this.Controls.Add(this.txtForoosh);
            this.Controls.Add(this.txtKharid);
            this.Controls.Add(this.txtBarcode);
            this.Controls.Add(this.txtSupplier);
            this.Controls.Add(this.txtCategory);
            this.Controls.Add(this.txtProductName);
            this.Controls.Add(this.lblTozihat);
            this.Controls.Add(this.lblVahed);
            this.Controls.Add(this.lblForoosh);
            this.Controls.Add(this.lblKharid);
            this.Controls.Add(this.lblBarcode);
            this.Controls.Add(this.lblSupplier);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.lblProductName);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnSabt);
            this.Controls.Add(this.dataGridView1);
            this.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmProducts";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "محصولات";
            this.Load += new System.EventHandler(this.FrmProducts_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnSabt;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn CategoryID;
        private System.Windows.Forms.DataGridViewTextBoxColumn SupplierID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PurchasePrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn SalePrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Barcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn IsActive;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblSupplier;
        private System.Windows.Forms.Label lblBarcode;
        private System.Windows.Forms.Label lblKharid;
        private System.Windows.Forms.Label lblForoosh;
        private System.Windows.Forms.Label lblVahed;
        private System.Windows.Forms.Label lblTozihat;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.TextBox txtCategory;
        private System.Windows.Forms.TextBox txtSupplier;
        private System.Windows.Forms.TextBox txtBarcode;
        private System.Windows.Forms.TextBox txtKharid;
        private System.Windows.Forms.TextBox txtForoosh;
        private System.Windows.Forms.TextBox txtVahed;
        private System.Windows.Forms.TextBox txtTozihat;
        private System.Windows.Forms.RadioButton rdbActive;
        private System.Windows.Forms.RadioButton rdbNotActive;
        private System.Windows.Forms.Label lblForooshgah;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtKala;
        private System.Windows.Forms.Button btnBazgasht;
    }
}