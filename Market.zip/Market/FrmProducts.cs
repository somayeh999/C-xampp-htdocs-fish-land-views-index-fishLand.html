﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmProducts : Form
    {
        public FrmProducts()
        {
            InitializeComponent();
        }
        int ProductID1 = -1;
        private void FrmProducts_Load(object sender, EventArgs e)
        {
            ClsMethods clsproduct = new ClsMethods();
            dataGridView1.DataSource = clsproduct.kolProducts();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ClsMethods clsproduct = new ClsMethods();
            if (dataGridView1.CurrentRow == null)
                return;
            string ProductName = txtProductName.Text;
            int CategoryID =int.Parse(txtCategory.Text);
            int SupplierID = int.Parse(txtSupplier.Text);
            int PurchasePrice =int.Parse(txtKharid.Text);
            int SalePrice =int.Parse(txtForoosh.Text);
            string Unit = txtVahed.Text;
            string Barcode = txtBarcode.Text;
            string Description = txtTozihat.Text;
            bool IsActive;
            if (rdbActive.Checked)
            {
                IsActive = true;
            }
            else if (rdbNotActive.Checked)
            {
                IsActive = false;
            }
            else
            {
                IsActive = false;
            }

            clsproduct.Update_Product(ProductID1,ProductName, CategoryID, SupplierID, PurchasePrice, SalePrice, Unit, Barcode, Description, IsActive);
            MessageBox.Show("ویرایش اطلاعات کالا با موفقیت انجام شد");
            dataGridView1.DataSource = clsproduct.kolProducts();
            txtBarcode.Text = txtCategory.Text = txtForoosh.Text = txtKharid.Text = txtProductName.Text = txtSupplier.Text = txtTozihat.Text = txtVahed.Text = "";
            rdbActive.Checked = false;
            rdbNotActive.Checked = false;
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            DataRowView drv = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
            txtProductName.Text = drv["ProductName"].ToString();
            txtCategory.Text = drv["CategoryID"].ToString();
            txtSupplier.Text = drv["SupplierID"].ToString();
            txtKharid.Text = drv["PurchasePrice"].ToString();
            txtForoosh.Text = drv["SalePrice"].ToString();
            txtVahed.Text = drv["Unit"].ToString();
            txtBarcode.Text = drv["Barcode"].ToString();
            txtTozihat.Text = drv["Description"].ToString();
            bool isActive = Convert.ToBoolean(drv["IsActive"]);
            rdbActive.Checked = isActive;
            rdbNotActive.Checked = !isActive;
            ProductID1 = (int)drv["ProductID"];


        }

        private void btnSabt_Click(object sender, EventArgs e)
        {
            ClsMethods clspro = new ClsMethods();
            if(txtProductName.Text=="")
            {
                MessageBox.Show("لطفا نام محصول را وارد کنید");
                txtProductName.Focus();
                return;
            }
            if(txtCategory.Text=="")
            {
                MessageBox.Show("لطفا کددسته بندی محصول را وارد کنید");
                txtCategory.Focus();
                return;
            }
            int dasteh;
            if (int.TryParse(txtCategory.Text, out dasteh) == false)
            {
                MessageBox.Show("لطفا کد دسته بندی را به عدد وارد کنید");
                txtCategory.Text = "";
                txtCategory.Focus();
                return;
            }

            if (txtSupplier.Text == "")
            {
                MessageBox.Show("لطفا کد شرکت را وارد کنید");
                txtSupplier.Focus();
                return;
            }
            int supplier;
            if(int.TryParse(txtSupplier.Text,out supplier)==false)
            {
                MessageBox.Show("لطفا کد شرکت را به عدد وارد کنید");
                txtSupplier.Text = "";
                txtSupplier.Focus();
                return;
            }
            if (txtKharid.Text == "")
            {
                MessageBox.Show("لطفا قیمت خرید را وارد کنید");
                txtKharid.Focus();
                return;
            }
            int kharid;
            if (int.TryParse(txtKharid.Text, out kharid) == false)
            {
                MessageBox.Show("لطفا قیمت خرید را به عدد وارد کنید");
                txtKharid.Text = "";
                txtKharid.Focus();
                return;
            }
            if (txtForoosh.Text == "")
            {
                MessageBox.Show("لطفا قیمت فروش را وارد کنید");
                txtForoosh.Focus();
                return;
            }
            int foroosh;
            if (int.TryParse(txtForoosh.Text, out foroosh) == false)
            {
                MessageBox.Show("لطفا قیمت فروش را به عدد وارد کنید");
                txtForoosh.Text = "";
                txtForoosh.Focus();
                return;
            }
            if (txtVahed.Text == "")
            {
                MessageBox.Show("لطفا واحد کالا را وارد کنید");
                txtVahed.Focus();
                return;
            }
            //کد بارکد را بعد بنویس یادت نره
            if (txtBarcode.Text == "")
            {
                MessageBox.Show("لطفا بارکد کالا را وارد کنید");
                txtBarcode.Focus();
                return;
            }

            //int barcod;
            //if (int.TryParse(txtBarcode.Text, out barcod) == false)
            //{
            //    MessageBox.Show("لطفا بارکد را به عدد وارد کنید");
            //    txtBarcode.Text = "";
            //    txtBarcode.Focus();
            //    return;
            //}
            if (txtTozihat.Text == "") 
            {
                MessageBox.Show("لطفا توضیحات کالا را وارد کنید");
                txtTozihat.Focus();
                return;
            }
            if(rdbActive.Checked==false && rdbNotActive.Checked ==false)
            {
                MessageBox.Show("لطفا موجود یا ناموجود بودن کالا را مشخص کنید");
                return;
            }
            string ProductName = txtProductName.Text;
            int CategoryID = dasteh;
            int SupplierID = supplier;
            int PurchasePrice = kharid;
            int SalePrice = foroosh;
            string Unit = txtVahed.Text;
            string Barcode = txtBarcode.Text;
            string Description = txtTozihat.Text;
            bool IsActive;
            if (rdbActive.Checked)
            {
                IsActive = true;
            }
            else if(rdbNotActive.Checked)
            {
                IsActive = false;
            }
            else
            {
                IsActive = false;
            }
            
            clspro.Insert_Products(ProductName, CategoryID, SupplierID, PurchasePrice, SalePrice, Unit, Barcode, Description, IsActive);
            MessageBox.Show("محصول جدید ثبت شد");
            dataGridView1.DataSource = clspro.kolProducts();
            txtBarcode.Text = txtCategory.Text = txtForoosh.Text = txtKharid.Text = txtProductName.Text = txtSupplier.Text = txtTozihat.Text = txtVahed.Text = "";
            rdbActive.Checked = false;
            rdbNotActive.Visible = false;

                

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            ClsMethods clspro = new ClsMethods();
            if (dataGridView1.CurrentRow == null)
                return;
            DialogResult result = MessageBox.Show("آیا از حذف این کالا اطمینان دارید","توجه",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
            if(result==DialogResult.Yes)
            {
                clspro.Delete_Product(ProductID1);
                dataGridView1.DataSource = clspro.kolProducts();
                txtBarcode.Text = txtCategory.Text = txtForoosh.Text = txtKharid.Text = txtProductName.Text = txtSupplier.Text = txtTozihat.Text = txtVahed.Text = "";
                rdbActive.Checked = false;
                rdbNotActive.Visible = false;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if(txtKala.Text=="")
            {
                MessageBox.Show("لطفا نام کالا را وارد کنید");
                return;
            }
            ClsMethods clsSerch = new ClsMethods();
            string ProductName1 = txtKala.Text;
            dataGridView1.DataSource = clsSerch.Search_Product(ProductName1);
        }

        private void btnBazgasht_Click(object sender, EventArgs e)
        {
            ClsMethods clsB = new ClsMethods();
            dataGridView1.DataSource = clsB.kolProducts();
        }
    }
}
