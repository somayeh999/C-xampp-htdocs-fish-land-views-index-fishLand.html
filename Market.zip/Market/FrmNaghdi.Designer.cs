﻿
namespace Market
{
    partial class FrmNaghdi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMablagh = new System.Windows.Forms.Label();
            this.lblKharid = new System.Windows.Forms.Label();
            this.txtMablagh = new System.Windows.Forms.TextBox();
            this.btnPardakht = new System.Windows.Forms.Button();
            this.btnFacNew = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMablagh
            // 
            this.lblMablagh.AutoSize = true;
            this.lblMablagh.Font = new System.Drawing.Font("B Homa", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblMablagh.Location = new System.Drawing.Point(36, 101);
            this.lblMablagh.Name = "lblMablagh";
            this.lblMablagh.Size = new System.Drawing.Size(32, 23);
            this.lblMablagh.TabIndex = 0;
            this.lblMablagh.Text = "مبلغ";
            // 
            // lblKharid
            // 
            this.lblKharid.AutoSize = true;
            this.lblKharid.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblKharid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblKharid.Font = new System.Drawing.Font("B Badr", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblKharid.Location = new System.Drawing.Point(30, 27);
            this.lblKharid.Name = "lblKharid";
            this.lblKharid.Size = new System.Drawing.Size(102, 46);
            this.lblKharid.TabIndex = 1;
            this.lblKharid.Text = "خرید سریع";
            // 
            // txtMablagh
            // 
            this.txtMablagh.Font = new System.Drawing.Font("B Homa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtMablagh.Location = new System.Drawing.Point(88, 94);
            this.txtMablagh.Name = "txtMablagh";
            this.txtMablagh.Size = new System.Drawing.Size(238, 37);
            this.txtMablagh.TabIndex = 2;
            // 
            // btnPardakht
            // 
            this.btnPardakht.Font = new System.Drawing.Font("Badr", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnPardakht.Location = new System.Drawing.Point(134, 162);
            this.btnPardakht.Name = "btnPardakht";
            this.btnPardakht.Size = new System.Drawing.Size(154, 42);
            this.btnPardakht.TabIndex = 3;
            this.btnPardakht.Text = "پرداخت نقدی";
            this.btnPardakht.UseVisualStyleBackColor = true;
            this.btnPardakht.Click += new System.EventHandler(this.btnPardakht_Click);
            // 
            // btnFacNew
            // 
            this.btnFacNew.Font = new System.Drawing.Font("Badr", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnFacNew.Location = new System.Drawing.Point(134, 210);
            this.btnFacNew.Name = "btnFacNew";
            this.btnFacNew.Size = new System.Drawing.Size(154, 43);
            this.btnFacNew.TabIndex = 4;
            this.btnFacNew.Text = "فاکتور جدید";
            this.btnFacNew.UseVisualStyleBackColor = true;
            this.btnFacNew.Click += new System.EventHandler(this.btnFacNew_Click);
            // 
            // FrmNaghdi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 289);
            this.Controls.Add(this.btnFacNew);
            this.Controls.Add(this.btnPardakht);
            this.Controls.Add(this.txtMablagh);
            this.Controls.Add(this.lblKharid);
            this.Controls.Add(this.lblMablagh);
            this.Name = "FrmNaghdi";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "خرید سریع";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMablagh;
        private System.Windows.Forms.Label lblKharid;
        private System.Windows.Forms.TextBox txtMablagh;
        private System.Windows.Forms.Button btnPardakht;
        private System.Windows.Forms.Button btnFacNew;
    }
}