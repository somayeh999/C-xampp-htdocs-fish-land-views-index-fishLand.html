﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmRoles : Form
    {
        public FrmRoles()
        {
            InitializeComponent();
        }
        int RoleID1 = -1;
        private void FrmRoles_Load(object sender, EventArgs e)
        {
            ClsMethods clsRol = new ClsMethods();
            dataGridView1.DataSource = clsRol.kolRoles();
        }

        private void btnSabt_Click(object sender, EventArgs e)
        {
            if(txtName.Text=="")
            {
                MessageBox.Show("لطفا نام نقش را وارد کنید");
                txtName.Focus();
                return;
            }
            ClsMethods clsRol = new ClsMethods();
            string RoleName = txtName.Text;
            clsRol.Insert_Role(RoleName);
            MessageBox.Show("اطلاعات با موفقیت ذخیره شد");
            dataGridView1.DataSource = clsRol.kolRoles();
            txtName.Text = "";

        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            DataRowView drv = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
            txtName.Text = drv["RoleName"].ToString();
            RoleID1 = (int)drv["RoleID"];
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ClsMethods clsR = new ClsMethods();
            if (dataGridView1.CurrentRow == null)
                return;
            
            string RoleName = txtName.Text;
            clsR.Update_Role(RoleID1, RoleName);
            MessageBox.Show("اطلاعات با موفقیت ویرایش شد");
            dataGridView1.DataSource = clsR.kolRoles();
            txtName.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            if (dataGridView1.CurrentRow == null)
                return;
            DialogResult result = MessageBox.Show("آیا از حذف این اطلاعات اطمینان دارید", "توجه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if(result==DialogResult.Yes)
            {
                ClsMethods clsR = new ClsMethods();
                clsR.Delete_Role(RoleID1);
                dataGridView1.DataSource = clsR.kolRoles();
                txtName.Text = "";
            }
            
        }
    }
}
