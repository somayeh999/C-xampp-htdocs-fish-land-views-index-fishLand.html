﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmUserRoles : Form
    {
        public FrmUserRoles()
        {
            InitializeComponent();
        }

        private void FrmUserRoles_Load(object sender, EventArgs e)
        {
            ClsMethods clsUserRol = new ClsMethods();
            dataGridView1.DataSource = clsUserRol.kolUserRoles();
        }
    }
}
