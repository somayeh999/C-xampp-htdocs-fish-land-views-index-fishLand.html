﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmCategoriees : Form
    {
        public FrmCategoriees()
        {
            InitializeComponent();
        }
        int CategoryID1 = -1;
        private void FrmCategoriees_Load(object sender, EventArgs e)
        {
            ClsMethods clscategori = new ClsMethods();
            dataGridView1.DataSource = clscategori.kolCategoriees();
        }

        private void btnSabt_Click(object sender, EventArgs e)
        {
            ClsMethods clscategori = new ClsMethods();
            if (txtCategoryName.Text=="")
            {
                MessageBox.Show("لطفا نام دسته را وارد کنید");
                txtCategoryName.Focus();
                return;
            }
            if(txtDescription.Text=="")
            {
                MessageBox.Show("توضیحات دسته را وارد کنید");
                txtDescription.Focus();
                return;
            }
            string CategoryName = txtCategoryName.Text;
            string Description = txtDescription.Text;
            clscategori.Insert_Categoriees(CategoryName, Description);
            MessageBox.Show("دسته جدید به درستی ثبت شد");
            dataGridView1.DataSource = clscategori.kolCategoriees();
            txtDescription.Text = txtCategoryName.Text = "";
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            DataRowView drv = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
            txtCategoryName.Text = drv["CategoryName"].ToString();
            txtDescription.Text = drv["Description"].ToString();
            CategoryID1 = (int)drv["CategoryID"];
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            ClsMethods clsCategori = new ClsMethods();
            if (dataGridView1.CurrentRow == null)
                return;
            DialogResult result = MessageBox.Show("آیا از حذف این اطلاعات مطمئن هستید؟ ","توجه", MessageBoxButtons.YesNo,
    MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                clsCategori.Delete_Categori(CategoryID1);
            dataGridView1.DataSource = clsCategori.kolCategoriees();
            txtCategoryName.Text = txtDescription.Text = "";
        }
             }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            ClsMethods clsCategori = new ClsMethods();
            if (dataGridView1.CurrentRow == null)
                return;
            string CategoryName = txtCategoryName.Text;
            string Description = txtDescription.Text;
            clsCategori.Update_Categori(CategoryID1,CategoryName, Description);
            MessageBox.Show("آیا از ویرایش این اطلاعات مطمین هستید؟", "توجه", MessageBoxButtons.YesNo);
            dataGridView1.DataSource = clsCategori.kolCategoriees();
            txtCategoryName.Text = txtDescription.Text = "";
        }
    }
}
