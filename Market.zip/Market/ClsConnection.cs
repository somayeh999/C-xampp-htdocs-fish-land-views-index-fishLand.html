﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace Market
{
    class ClsConnection
    {
        public static string connection = "server=DESKTOP-2JS5RNS;database=dbMarket;Integrated security=True";

    }
}
