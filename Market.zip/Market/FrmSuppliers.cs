﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmSuppliers : Form
    {
        public FrmSuppliers()
        {
            InitializeComponent();
        }
        int SupplierID1 = -1;
        private void FrmSuppliers_Load(object sender, EventArgs e)
        {
            ClsMethods clsSupplier = new ClsMethods();
            dataGridView1.DataSource = clsSupplier.kolSuppliers();
        }

        private void btnSabt_Click(object sender, EventArgs e)
        {
            ClsMethods clsSupplier = new ClsMethods();
            if (txtNameSupplier.Text=="")
            {
                MessageBox.Show("لطفا نام شرکت تامین کننده را وارد کنید");
                txtNameSupplier.Focus();
                return;
            }
            if(txtFamilyVisitor.Text=="")
            {
                MessageBox.Show("لطفا نام ویزیتور را وارد کنید");
                txtFamilyVisitor.Focus();
                return;
            }
            if (txtTell.Text == "")
            {
                MessageBox.Show("لطفا تلفن ویزیتور  را وارد کنید");
                txtTell.Focus();
                return;
            }
            if (txtAdress.Text == "")
            {
                MessageBox.Show("لطفا آدرس دفتر شرکت  را وارد کنید");
                txtAdress.Focus();
                return;
            }
            string SupplierName = txtNameSupplier.Text;
            string ContactName = txtFamilyVisitor.Text;
            string Phone = txtTell.Text;
            string Address = txtAdress.Text;
            clsSupplier.Insert_Supplier(SupplierName, ContactName, Phone, Address);
            MessageBox.Show("اطلاعات با موفقیت ثبت شد");
            dataGridView1.DataSource = clsSupplier.kolSuppliers();
            txtAdress.Text = txtFamilyVisitor.Text = txtNameSupplier.Text = txtTell.Text = "";
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ClsMethods clsSupplier = new ClsMethods();
            if (dataGridView1.CurrentRow == null)
                return;
            string SupplierName = txtNameSupplier.Text;
            string ContactName = txtFamilyVisitor.Text;
            string Phone = txtTell.Text;
            string Address = txtAdress.Text;
            clsSupplier.Update_Supplier(SupplierID1, SupplierName, ContactName, Phone, Address);
            MessageBox.Show("اطلاعات با موفقیت ویرایش شد");
            dataGridView1.DataSource = clsSupplier.kolSuppliers();
            txtAdress.Text = txtFamilyVisitor.Text = txtNameSupplier.Text = txtTell.Text = "";
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            DataRowView drv = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
            txtNameSupplier.Text = drv["SupplierName"].ToString();
            txtFamilyVisitor.Text = drv["ContactName"].ToString();
            txtTell.Text = drv["Phone"].ToString();
            txtAdress.Text = drv["Address"].ToString();
            SupplierID1 = (int)drv["SupplierID"];
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            if (dataGridView1.CurrentRow == null)
                return;
            
            DialogResult result=MessageBox.Show("آیا از حذف این اطلاعات اطمینان دارید","توجه",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
            if(result==DialogResult.Yes)
            {
                ClsMethods clsSupplier = new ClsMethods();
                clsSupplier.Delete_Supplier(SupplierID1);
                dataGridView1.DataSource = clsSupplier.kolSuppliers();
                txtAdress.Text = txtFamilyVisitor.Text = txtNameSupplier.Text = txtTell.Text = "";
            }
            


        }
    }
}
