﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmStock : Form
    {
        public FrmStock()
        {
            InitializeComponent();
        }
        int StockID1 = -1;
        private void FrmStock_Load(object sender, EventArgs e)
        {
            ClsMethods clsStock = new ClsMethods();
            dataGridView1.DataSource = clsStock.kolStock();
        }
        
        private void btnSabt_Click(object sender, EventArgs e)
        {
            txtUp.Text = DateTime.Now.ToString();
            ClsMethods clsStock = new ClsMethods();

            //if (txtStockID.Text == "")
            //{
            //    MessageBox.Show("لطفا کد بار انبار را وارد کن");
            //    txtStockID.Focus();
            //    return;
            //}
            //int Sid;
            //if (int.TryParse(txtStockID.Text, out Sid) == false)
            //{
            //    MessageBox.Show("لطفا کدبار را به عدد وارد کنید");
            //    txtStockID.Text = "";
            //    txtStockID.Focus();
            //    return;
            //}
            if (txtProductID.Text == "")
            {
                MessageBox.Show("لطفا کد محصول را وارد کن");
                txtProductID.Focus();
                return;
            }
            int Pid;
            if (int.TryParse(txtProductID.Text, out Pid) == false)
            {
                MessageBox.Show("لطفا کد محصول را به عدد وارد کنید");
                txtProductID.Text = "";
                txtProductID.Focus();
                return;
            }
            if(txtMini.Text=="")
            {
                MessageBox.Show("لطفا تعداد حداقل موجودی محصول را وارد کنید");
                txtMini.Focus();
                return;
            }
            int min;
            if(int.TryParse(txtMini.Text,out min)==false)
            {
                MessageBox.Show("لطفا حداقل موجودی را به عدد وارد کنید");
                txtMini.Text = "";
                txtMini.Focus();
            }
            if (txtQuantity.Text == "")
            {
                MessageBox.Show("لطفا تعداد حداقل موجودی محصول را وارد کنید");
                txtQuantity.Focus();
                return;
            }
            int quan;
            if (int.TryParse(txtQuantity.Text, out quan) == false)
            {
                MessageBox.Show("لطفا حداقل موجودی را به عدد وارد کنید");
                txtQuantity.Text = "";
                txtQuantity.Focus();
            }
           
            DateTime LastUpdated = DateTime.Parse(txtUp.Text);
            clsStock.Insert_Stock(Pid, quan, LastUpdated, min);
            MessageBox.Show("اطلاعات با موفقیت ثبت شد");
            dataGridView1.DataSource = clsStock.kolStock();
            txtMini.Text = txtProductID.Text = txtQuantity.Text = txtStockID.Text = txtUp.Text = "";
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            DataRowView drv = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
            txtStockID.Text = drv["StockID"].ToString();
            txtProductID.Text = drv["ProductID"].ToString();
            txtQuantity.Text = drv["Quantity"].ToString();
            txtUp.Text = drv["LastUpdated"].ToString();
            txtMini.Text = drv["MinStockLevel"].ToString();
            StockID1 = (int)drv["StockID"];
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            // txtUp.Text = DateTime.Now.ToString();
            ClsMethods clsStock = new ClsMethods();
            int Pid; int quan; int min;
            int.TryParse(txtProductID.Text, out Pid);
            int.TryParse(txtQuantity.Text, out quan);
            DateTime LastUpdated = DateTime.Parse(txtUp.Text);
            int.TryParse(txtMini.Text, out min);
            
            clsStock.Update_Stock(StockID1,Pid, quan, LastUpdated, min);
            MessageBox.Show("اطلاعات با موفقیت ویرایش شد");
            dataGridView1.DataSource = clsStock.kolStock();
            txtMini.Text = txtProductID.Text = txtQuantity.Text = txtStockID.Text = txtUp.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            ClsMethods clsStock = new ClsMethods();
            clsStock.Delete_Stock(StockID1);
            MessageBox.Show("اطلاعات با موفقیت حذف شد");
            dataGridView1.DataSource = clsStock.kolStock();
            txtMini.Text = txtProductID.Text = txtQuantity.Text = txtStockID.Text = txtUp.Text = "";
        }
    }
}
