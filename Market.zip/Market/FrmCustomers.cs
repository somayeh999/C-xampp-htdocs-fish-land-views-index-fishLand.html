﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmCustomers : Form
    {
        public FrmCustomers()
        {
            InitializeComponent();
        }
        int CustomerID1 = -1;
        private void FrmCustomers_Load(object sender, EventArgs e)
        {
            ClsMethods clscustomer = new ClsMethods();
            dataGridView1.DataSource = clscustomer.kolCustomers();
        }

        private void btnSabt_Click(object sender, EventArgs e)
        {
            ClsMethods clscustomer = new ClsMethods();
            if(txtName.Text=="")
            {
                MessageBox.Show("لطفا نام مشتری را وارد کنید");
                txtName.Focus();
                return;
            }
            if (txtFamily.Text == "")
            {
                MessageBox.Show("لطفا نام خانوادگی مشتری را وارد کنید");
                txtFamily.Focus();
                return;
            }
            if (txtTell.Text == "")
            {
                MessageBox.Show("لطفا تلفن مشتری را وارد کنید");
                txtTell.Focus();
                return;
            }
           int tell;
            if(int.TryParse(txtTell.Text,out tell )==false)
                    {
                MessageBox.Show("لطفا تلفن مشتری را با فرمت عددی وارد کنید");
                txtTell.Text = "";
                txtTell.Focus();
                return;
            }
            if (txtAddress.Text == "")
            {
                MessageBox.Show("لطفا آدرس مشتری را وارد کنید");
                txtAddress.Focus();
                return;
            }
            
            
            txtDate.Text = DateTime.Now.ToString();
            
            string FirstName = txtName.Text;
            string LastName = txtFamily.Text;
            string PhoneNumber = txtTell.Text;
            string Address = txtAddress.Text;
            DateTime RegistrationDate = DateTime.Parse(txtDate.Text);
            clscustomer.Insert_Customers(FirstName, LastName, PhoneNumber, Address, RegistrationDate);
            
            MessageBox.Show("مشخصات مشتری به درستی ثبت شد");
            dataGridView1.DataSource = clscustomer.kolCustomers();
           txtAddress.Text=txtDate.Text=txtFamily.Text=txtName.Text=txtTell.Text="";
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            DataRowView drv = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
            txtName.Text = drv["FirstName"].ToString();
            txtFamily.Text=drv["LastName"].ToString();
            txtTell.Text = drv["PhoneNumber"].ToString();
            txtAddress.Text = drv["Address"].ToString();
            txtDate.Text = drv["RegistrationDate"].ToString();
            CustomerID1 = (int)drv["CustomerID"];
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ClsMethods clscustomer = new ClsMethods();
            if (dataGridView1.CurrentRow == null)
                return;
            string FirstName = txtName.Text;
            string LastName = txtFamily.Text;
            string PhoneNumber = txtTell.Text;
            string Address = txtAddress.Text;
            DateTime RegistrationDate = DateTime.Parse(txtDate.Text);
            clscustomer.Update_Customer(CustomerID1,FirstName, LastName, PhoneNumber, Address, RegistrationDate);

            MessageBox.Show("مشخصات مشتری به درستی ویرایش شد");
            dataGridView1.DataSource = clscustomer.kolCustomers();
            txtAddress.Text = txtDate.Text = txtFamily.Text = txtName.Text = txtTell.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            ClsMethods clscustomer = new ClsMethods();
            DialogResult result = MessageBox.Show(
    "آیا از حذف این اطلاعات مطمئن هستید؟",
    "توجه",
    MessageBoxButtons.YesNo,
    MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                try
                {
                    clscustomer.Delete_Customer(CustomerID1);
                    dataGridView1.DataSource = clscustomer.kolCustomers();

                    txtAddress.Text = "";
                    txtDate.Text = "";
                    txtFamily.Text = "";
                    txtName.Text = "";
                    txtTell.Text = "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("خطا در حذف اطلاعات: " + ex.Message);
                }
            }
        }
    }
}
