﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmSalesInvoiceItems : Form
    {
        public FrmSalesInvoiceItems()
        {
            InitializeComponent();
        }

        private void FrmSalesInvoiceItems_Load(object sender, EventArgs e)
        {
            ClsMethods clsSalesInvoicItem = new ClsMethods();
            dataGridView1.DataSource = clsSalesInvoicItem.kolSalesInvoiceItems();
        }
    }
}
