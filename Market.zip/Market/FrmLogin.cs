﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

       

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            string managment = "alsan1";
            string seller = "alsan2";
            string stocker = "alsan3";
            string passManagment = "1234";
            string passSeller = "2345";
            string passStocker = "3456";
            if(txtName.Text=="")
            {
                MessageBox.Show("لطفا نام کاربری را وارد کنید");
                txtName.Focus();
                return;
            }
            if (txtPass.Text == "")
            {
                MessageBox.Show("لطفا رمز عبور خود را وارد کنید");
                txtPass.Focus();
                return;
            }
            if(txtName.Text!=managment)
            {
                if(txtName.Text!=seller)
                {
                    if(txtName.Text!=stocker)
                    {
                        MessageBox.Show("نام کاربری صحیح را وارد کنید");
                        txtName.Text = "";
                        txtName.Focus();
                        return;
                    }
                }
            }
            if(txtPass.Text!= passManagment)
            {
                if(txtPass.Text!= passSeller)
                {
                    if(txtPass.Text!= passStocker)
                    {
                        MessageBox.Show("لطفا رمز عبور صحیح را وارد کنید");
                        txtPass.Text = "";
                        txtPass.Focus();
                        return;
                    }
                }
            }
            if(txtName.Text== managment && txtPass.Text== passManagment)
            {
                FrmMain frmModiriat = new FrmMain();
                frmModiriat.Show();
            }

            if(txtName.Text== seller && txtPass.Text== passSeller)
            {
                FrmForoosh frmForoosh = new FrmForoosh();
                frmForoosh.Show();
            }

            if (txtName.Text == stocker && txtPass.Text == passStocker)
            {
               FrmStock frmAnbar = new FrmStock();
                frmAnbar.Show();
            }



        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblPass_Click(object sender, EventArgs e)
        {

        }

        private void lblName_Click(object sender, EventArgs e)
        {

        }
    }
}
