﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Market
{
    class ClsMethods
    {
        SqlConnection mycon = new SqlConnection(ClsConnection.connection);

        public DataTable kolCategoriees()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_categoriees", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
        public void Insert_Categoriees(string CategoryName1,string Description1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand insCategori = new SqlCommand("Insert_Categoriees", mycon);
            insCategori.CommandType = CommandType.StoredProcedure;
            insCategori.Parameters.AddWithValue("@CategoryName", CategoryName1);
            insCategori.Parameters.AddWithValue("@Description", Description1);
            insCategori.ExecuteNonQuery();
            mycon.Close();

        }
        public void Update_Categori(int CategoryID1,string CategoryName1, string Description1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand upCategori = new SqlCommand("Update_Categori", mycon);
            upCategori.CommandType = CommandType.StoredProcedure;
            upCategori.Parameters.AddWithValue("@CategoryID1", CategoryID1);
            upCategori.Parameters.AddWithValue("@CategoryName1", CategoryName1);
            upCategori.Parameters.AddWithValue("@Description1", Description1);
            upCategori.ExecuteNonQuery();
            mycon.Close();

        }
        public void Delete_Categori(int CategoryID1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand delCategori = new SqlCommand("Delete_Categori", mycon);
            delCategori.CommandType = CommandType.StoredProcedure;
            delCategori.Parameters.AddWithValue("@CategoryID1", CategoryID1);

            delCategori.ExecuteNonQuery();
            mycon.Close();

        }

        public DataTable kolCustomers()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_customers", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
        public void Insert_Customers(string FirstName1,string LastName1,string PhoneNumber1,string Address1,DateTime RegistrationDate1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand insCustomer = new SqlCommand("Insert_Customers", mycon);
            insCustomer.CommandType = CommandType.StoredProcedure;
            insCustomer.Parameters.AddWithValue("@FirstName", FirstName1);
            insCustomer.Parameters.AddWithValue("@LastName", LastName1);
            insCustomer.Parameters.AddWithValue("@PhoneNumber", PhoneNumber1);
            insCustomer.Parameters.AddWithValue("@Address", Address1);
            insCustomer.Parameters.AddWithValue("@RegistrationDate",RegistrationDate1);
            insCustomer.ExecuteNonQuery();
            mycon.Close();
        }
        public void Update_Customer(int CustomerID1, string FirstName1, string LastName1, string PhoneNumber1, string Address1, DateTime RegistrationDate1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand upCustomer = new SqlCommand("Update_Customer", mycon);
            upCustomer.CommandType = CommandType.StoredProcedure;
            upCustomer.Parameters.AddWithValue("@CustomerID1", CustomerID1);
            upCustomer.Parameters.AddWithValue("@FirstName1", FirstName1);
            upCustomer.Parameters.AddWithValue("@LastName1", LastName1);
            upCustomer.Parameters.AddWithValue("@PhoneNumber1", PhoneNumber1);
            upCustomer.Parameters.AddWithValue("@Address1", Address1);
            upCustomer.Parameters.AddWithValue("@RegistrationDate1", RegistrationDate1);
            upCustomer.ExecuteNonQuery();
            mycon.Close();
        }
        public void Delete_Customer(int CustomerID1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand delCustomer = new SqlCommand("Delete_Customer", mycon);
            delCustomer.CommandType = CommandType.StoredProcedure;
            delCustomer.Parameters.AddWithValue("@CustomerID1", CustomerID1);

            delCustomer.ExecuteNonQuery();
            mycon.Close();
        }
        public DataTable kolPermissions()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_permissions", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
        public void Insert_Permissions(string PermissionName1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand insPer = new SqlCommand("Insert_Permissions", mycon);
            insPer.CommandType = CommandType.StoredProcedure;
            insPer.Parameters.AddWithValue("@PermissionName", PermissionName1);

            insPer.ExecuteNonQuery();
            mycon.Close();

        }
        public void Update_Permission( int PermissionsID1, string PermissionName1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand upPer = new SqlCommand("Update_Permission", mycon);
            upPer.CommandType = CommandType.StoredProcedure;
            upPer.Parameters.AddWithValue("@PermissionsID1", PermissionsID1);
            upPer.Parameters.AddWithValue("@PermissionName1", PermissionName1);

            upPer.ExecuteNonQuery();
            mycon.Close();

        }
        public void Delete_Permmision(int PermissionsID1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand dlPer = new SqlCommand("Delete_Permmision", mycon);
            dlPer.CommandType = CommandType.StoredProcedure;
            dlPer.Parameters.AddWithValue("@PermissionsID1", PermissionsID1);
            dlPer.ExecuteNonQuery();
            mycon.Close();

        }
        public DataTable kolProducts()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_products", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
        public void Insert_Products ( string ProductName1, int CategoryID1, int SupplierID1, int PurchasePrice1, int SalePrice1, string Unit1, string Barcode1, string Description1,bool IsActive1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand insProduct = new SqlCommand("Insert_Products", mycon);
            insProduct.CommandType = CommandType.StoredProcedure;
            insProduct.Parameters.AddWithValue("@ProductName", ProductName1);
            insProduct.Parameters.AddWithValue("@CategoryID", CategoryID1);
            insProduct.Parameters.AddWithValue("@SupplierID", SupplierID1);
            insProduct.Parameters.AddWithValue("@PurchasePrice", PurchasePrice1);
            insProduct.Parameters.AddWithValue("@SalePrice", SalePrice1);
            insProduct.Parameters.AddWithValue("@Unit", Unit1);
            insProduct.Parameters.AddWithValue("@Barcode", Barcode1);
            insProduct.Parameters.AddWithValue("@Description", Description1);
            insProduct.Parameters.AddWithValue("@IsActive", IsActive1);
            insProduct.ExecuteNonQuery();
            mycon.Close();
        }
        public void Update_Product(int ProductID1, string ProductName1, int CategoryID1, int SupplierID1, int PurchasePrice1, int SalePrice1, string Unit1, string Barcode1, string Description1, bool IsActive1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand upProduct = new SqlCommand("Update_Product", mycon);
            upProduct.CommandType = CommandType.StoredProcedure;
            upProduct.Parameters.AddWithValue("@ProductID1", ProductID1);
            upProduct.Parameters.AddWithValue("@ProductName1", ProductName1);
            upProduct.Parameters.AddWithValue("@CategoryID1", CategoryID1);
            upProduct.Parameters.AddWithValue("@SupplierID1", SupplierID1);
            upProduct.Parameters.AddWithValue("@PurchasePrice1", PurchasePrice1);
            upProduct.Parameters.AddWithValue("@SalePrice1", SalePrice1);
            upProduct.Parameters.AddWithValue("@Unit1", Unit1);
            upProduct.Parameters.AddWithValue("@Barcode1", Barcode1);
            upProduct.Parameters.AddWithValue("@Description1", Description1);
            upProduct.Parameters.AddWithValue("@IsActive1", IsActive1);
            upProduct.ExecuteNonQuery();
            mycon.Close();
        }
        public void Delete_Product(int ProductID1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand delProduct = new SqlCommand("Delete_Product", mycon);
            delProduct.CommandType = CommandType.StoredProcedure;
            delProduct.Parameters.AddWithValue("@ProductID1", ProductID1);

            delProduct.ExecuteNonQuery();
            mycon.Close();
        }
        public DataTable Search_Product(string ProductName1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand serchProduct = new SqlCommand("Search_Product", mycon);
            serchProduct.CommandType = CommandType.StoredProcedure;
            serchProduct.Parameters.AddWithValue("@ProductName1", ProductName1);
            serchProduct.ExecuteNonQuery();
            SqlDataReader rd = serchProduct.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
        public DataTable kolRoles()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_roles", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
        public void Insert_Role(string RoleName1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand insRol = new SqlCommand("Insert_Role", mycon);
            insRol.CommandType = CommandType.StoredProcedure;
            insRol.Parameters.AddWithValue("@RoleName", RoleName1);
            insRol.ExecuteNonQuery();
            mycon.Close();
        }
        public void Update_Role(int RoleID1, string RoleName1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand upsRol = new SqlCommand("Update_Role", mycon);
            upsRol.CommandType = CommandType.StoredProcedure;
            upsRol.Parameters.AddWithValue("@RoleID1", RoleID1);
            upsRol.Parameters.AddWithValue("@RoleName1", RoleName1);
            upsRol.ExecuteNonQuery();
            mycon.Close();
        }
        public void Delete_Role(int RoleID1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand delRol = new SqlCommand("Delete_Role", mycon);
            delRol.CommandType = CommandType.StoredProcedure;
            delRol.Parameters.AddWithValue("@RoleID1", RoleID1);
            delRol.ExecuteNonQuery();
            mycon.Close();
        }
        public DataTable kolRolPermissions()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_rolPermissions", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
        public DataTable kolSalesInvoiceItems()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_salesInvoiceItems", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
       
        public int Insert_SalesInvoiceItem( int InvoiceID, DataRow row)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand insInvoiceItem = new SqlCommand("Insert_SalesInvoiceItem", mycon);
            insInvoiceItem.CommandType = CommandType.StoredProcedure;

            insInvoiceItem.Parameters.AddWithValue("@InvoiceID", InvoiceID);
            insInvoiceItem.Parameters.AddWithValue("@ProductID", row["ProductID"]);
            insInvoiceItem.Parameters.AddWithValue("@productName", row["productName"]);
            insInvoiceItem.Parameters.AddWithValue("@Quantity", row["Quantity"]);
            insInvoiceItem.Parameters.AddWithValue("@UnitPrice", row["UnitPrice"]);
            insInvoiceItem.Parameters.AddWithValue("@LineTotal", row["LineTotal"]);

            insInvoiceItem.ExecuteNonQuery();

            mycon.Close();
            return InvoiceID;
        }

       

            public DataTable kolSalesInvoices()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_salesInvoices", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }

        public DataTable ReportDailySales(DateTime date)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = mycon;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "SP_ReportDailySales";

            cmd.Parameters.AddWithValue("@InvoiceDate", date.Date);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            return dt;
        }
        public int Insert_Invoice(DateTime InvoiceDate1, string LastName1, int TotalAmount1, int DiscountAmount1, int FinalAmount1, int UserID1)
        {
            int invoiceId = 0; 
            if (mycon.State == ConnectionState.Closed)
            {
                mycon.Open();
            }

            
            using (SqlCommand cmdInv = new SqlCommand("Insert_Invoice", mycon))
            {
                cmdInv.CommandType = CommandType.StoredProcedure;

                
                cmdInv.Parameters.AddWithValue("@InvoiceDate", InvoiceDate1);
                cmdInv.Parameters.AddWithValue("@LastName", LastName1);
                cmdInv.Parameters.AddWithValue("@TotalAmount", TotalAmount1);
                cmdInv.Parameters.AddWithValue("@DiscountAmount", DiscountAmount1);
                cmdInv.Parameters.AddWithValue("@FinalAmount", FinalAmount1);
                cmdInv.Parameters.AddWithValue("@UserID", UserID1);

                try
                {
                   
                    object result = cmdInv.ExecuteScalar();

                    
                    if (result != null && result != DBNull.Value)
                    {
                        invoiceId = Convert.ToInt32(result);
                    }
                    else
                    {
                       
                    }
                }
                catch (Exception ex)
                {
                    
                   // Log.Error("Error inserting invoice: " + ex.Message); 
                    throw; 
                }
                
            }

            return invoiceId;
           
        }



        public DataTable kolStock()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_stock", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
        public void Insert_Stock(int ProductID1,int Quantity1,DateTime LastUpdated1,int MinStockLevel1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand insStock = new SqlCommand("Insert_Stock", mycon);
            insStock.CommandType = CommandType.StoredProcedure;

            insStock.Parameters.AddWithValue("@ProductID", ProductID1);
            insStock.Parameters.AddWithValue("@Quantity", Quantity1);
            insStock.Parameters.AddWithValue("@LastUpdated", LastUpdated1);
            insStock.Parameters.AddWithValue("@MinStockLevel", MinStockLevel1);
            
            insStock.ExecuteNonQuery();
            
            mycon.Close();

        }

        public void Update_Stock(int StockID1,int ProductID1, int Quantity1, DateTime LastUpdated1, int MinStockLevel1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand upStock = new SqlCommand("Update_Stock", mycon);
            upStock.CommandType = CommandType.StoredProcedure;
            upStock.Parameters.AddWithValue("@StockID1", StockID1);
            upStock.Parameters.AddWithValue("@ProductID1", ProductID1);
            upStock.Parameters.AddWithValue("@Quantity1", Quantity1);
            upStock.Parameters.AddWithValue("@LastUpdated1", LastUpdated1);
            upStock.Parameters.AddWithValue("@MinStockLevel1", MinStockLevel1);

            upStock.ExecuteNonQuery();

            mycon.Close();

        }
        public void Delete_Stock(int StockID1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand dlStock = new SqlCommand("Delete_Stock", mycon);
            dlStock.CommandType = CommandType.StoredProcedure;
            dlStock.Parameters.AddWithValue("@StockID1", StockID1);
            dlStock.ExecuteNonQuery();
            mycon.Close();

        }
        public DataTable kolSuppliers()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_suppliers", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
        public void Insert_Supplier(string SupplierName1, string ContactName1, string Phone1, string Address1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand insSupplier = new SqlCommand("Insert_Supplier", mycon);
            insSupplier.CommandType = CommandType.StoredProcedure;
            insSupplier.Parameters.AddWithValue("@SupplierName", SupplierName1);
            insSupplier.Parameters.AddWithValue("@ContactName", ContactName1);
            insSupplier.Parameters.AddWithValue("@Phone", Phone1);
            insSupplier.Parameters.AddWithValue("@Address", Address1);
            insSupplier.ExecuteNonQuery();
            mycon.Close();
        }
        public void Update_Supplier(int SupplierID1, string SupplierName1, string ContactName1, string Phone1, string Address1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand upSupplier = new SqlCommand("Update_Supplier", mycon);
            upSupplier.CommandType = CommandType.StoredProcedure;
            upSupplier.Parameters.AddWithValue("@SupplierID1", SupplierID1);
            upSupplier.Parameters.AddWithValue("@SupplierName1", SupplierName1);
            upSupplier.Parameters.AddWithValue("@ContactName1", ContactName1);
            upSupplier.Parameters.AddWithValue("@Phone1", Phone1);
            upSupplier.Parameters.AddWithValue("@Address1", Address1);
            upSupplier.ExecuteNonQuery();
            mycon.Close();
        }
        public void Delete_Supplier(int SupplierID1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand delSupplier = new SqlCommand("Delete_Supplier", mycon);
            delSupplier.CommandType = CommandType.StoredProcedure;
            delSupplier.Parameters.AddWithValue("@SupplierID1", SupplierID1);
            delSupplier.ExecuteNonQuery();
            mycon.Close();
        }
        public DataTable kolUserRoles()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_userRoles", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
        public DataTable kolUsers()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("kol_users", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }
        public void Insert_User(string UserName1, string PasswordHash1, string FullName1, int RoleID1, bool IsActive1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand insUser = new SqlCommand("Insert_User", mycon);
            insUser.CommandType = CommandType.StoredProcedure;
            insUser.Parameters.AddWithValue("@UserName", UserName1);
            insUser.Parameters.AddWithValue("@PasswordHash", PasswordHash1);
            insUser.Parameters.AddWithValue("@FullName", FullName1);
            insUser.Parameters.AddWithValue("@RoleID", RoleID1);
            insUser.Parameters.AddWithValue("@IsActive", IsActive1);
            insUser.ExecuteNonQuery();
            mycon.Close();
            
        }
        public void Update_User(int UserID1, string UserName1, string PasswordHash1, string FullName1, int RoleID1, bool IsActive1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand upsUser = new SqlCommand("Update_User", mycon);
            upsUser.CommandType = CommandType.StoredProcedure;
            upsUser.Parameters.AddWithValue("@UserID1", UserID1);
            upsUser.Parameters.AddWithValue("@UserName1", UserName1);
            upsUser.Parameters.AddWithValue("@PasswordHash1", PasswordHash1);
            upsUser.Parameters.AddWithValue("@FullName1", FullName1);
            upsUser.Parameters.AddWithValue("@RoleID1", RoleID1);
            upsUser.Parameters.AddWithValue("@IsActive1", IsActive1);
            upsUser.ExecuteNonQuery();
            mycon.Close();

        }
        public void Delete_User(int UserID1)
        {
            mycon.Close();
            mycon.Open();
            SqlCommand upsUser = new SqlCommand("Delete_User", mycon);
            upsUser.CommandType = CommandType.StoredProcedure;
            upsUser.Parameters.AddWithValue("@UserID1", UserID1);
            upsUser.ExecuteNonQuery();
            mycon.Close();

        }
        public DataTable TableRizFactor()
        {
            mycon.Close();
            mycon.Open();
            SqlCommand command = new SqlCommand("Riz_Factor", mycon);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rd);
            mycon.Close();
            return dt;
        }


    }
}
