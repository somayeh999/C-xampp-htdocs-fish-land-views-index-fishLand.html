﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmPermissions : Form
    {
        public FrmPermissions()
        {
            InitializeComponent();
        }
       int PermissionsID1=-1;
        private void FrmPermissions_Load(object sender, EventArgs e)
        {
            ClsMethods clspermission = new ClsMethods();
            dataGridView1.DataSource = clspermission.kolPermissions();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            DataRowView drv = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
            txtPerName.Text = drv["PermissionName"].ToString();

            PermissionsID1 = (int)drv["PermissionsID"];
        }

        private void btnSabt_Click(object sender, EventArgs e)
        {
            ClsMethods clsper = new ClsMethods();
            if (txtPerName.Text == "")
            {
                MessageBox.Show("لطفا نام مشتری را وارد کنید");
               txtPerName.Focus();
                return;
            }
            string PermissionName = txtPerName.Text;
            clsper.Insert_Permissions(PermissionName);
            MessageBox.Show("اطلاعات با موفقیت ثبت شد");
            dataGridView1.DataSource = clsper.kolPermissions();
            txtPerName.Text = "";
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ClsMethods clsper = new ClsMethods();
            if (dataGridView1.CurrentRow == null)
                return;
            string PermissionName = txtPerName.Text;
            clsper.Update_Permission(PermissionsID1,PermissionName);
            MessageBox.Show("اطلاعات با موفقیت ویرایش شد");
            dataGridView1.DataSource = clsper.kolPermissions();
            txtPerName.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            ClsMethods clsper = new ClsMethods();
            if (dataGridView1.CurrentRow == null)
                return;
            clsper.Delete_Permmision(PermissionsID1);
            MessageBox.Show("اطلاعات با موفقیت حذف شد");
            dataGridView1.DataSource = clsper.kolPermissions();
            txtPerName.Text = "";
        }
    }
}
