﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmForoosh : Form
    {
        DataTable dtInvoiceItems = new DataTable();
        private TextBox txtBarcodeInput;
        private TextBox txtBarcodeDisplay;
       
        

        private void CalculateTotal()
        {
            decimal total = 0;

            foreach (DataRow row in dtInvoiceItems.Rows)
            {
                total += Convert.ToDecimal(row["LineTotal"]);
            }

            lblTotalAmount.Text = total.ToString("N0");
            txtTotalAmount.Text = total.ToString();
            txtNamayeshi.Text = "ریال" + "     " + total.ToString("N0");
        }
        public FrmForoosh()
        {
            InitializeComponent();

            SetupBarcodeReader();
        }
        private void SetupBarcodeReader()
        {

            txtBarcodeInput = new TextBox
            {
                Visible = false,
                Font = new Font("arial", 1f),
                ReadOnly = false,
                TabStop = false,
                Name = "txtBarcodeInput"
            };
            this.Controls.Add(txtBarcodeInput);
            txtBarcodeInput.KeyDown += txtBarcodeInput_keyDown;

            txtBarcodeDisplay = this.Controls.OfType<TextBox>().FirstOrDefault(tb => tb.Name == "txtBarcodeDisplay");
            if (txtBarcodeDisplay == null)
            {
                txtBarcodeDisplay = new TextBox
                {
                    Location = new Point(50, 50),
                    Size = new Size(200, 20),
                    Font = new Font("Arial", 10f),
                    ReadOnly = true,
                    TabStop = false,
                    Name = "txtBarcodeDisplay"
                };
                this.Controls.Add(txtBarcodeDisplay);
            }
            else
            {
                txtBarcodeDisplay.ReadOnly = true;
                txtBarcodeDisplay.TabStop = false;
            }
        }
        private void txtBarcodeInput_keyDown(object sender, KeyEventArgs e)
        {
           
            if (e.KeyCode == Keys.Enter)
            {
                string barcode = txtBarcodeInput.Text;
                if (txtBarcodeDisplay != null)
                {
                    txtBarcodeDisplay.Text = "";
                    txtBarcodeDisplay.Text = barcode;
                    txtBarcodeDisplay.Text = barcode;
                    txtBarcodeDisplay.Text = "";
                }

                PreProcessControlState(barcode);
                txtBarcodeInput.Clear();
                e.SuppressKeyPress = true;
            }
        }
        private void PreProcessControlState(string barcode)
        {
            if (string.IsNullOrEmpty(barcode)) return;
            MessageBox.Show($"بارکد خوانده شد:{ barcode}");
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (txtBarcodeInput != null && !txtBarcodeInput.Focused)
            {
                txtBarcodeDisplay.Text = "";
                txtBarcodeInput.Focus();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void FrmForoosh_Load(object sender, EventArgs e)
        {
            txtBarcodeInput.Focus();

            ClsMethods clsUser = new ClsMethods();
            dtInvoiceItems.Columns.Add("ProductID", typeof(int));
            dtInvoiceItems.Columns.Add("productName", typeof(string));
            dtInvoiceItems.Columns.Add("Quantity", typeof(decimal));
            dtInvoiceItems.Columns.Add("UnitPrice", typeof(decimal));
            dtInvoiceItems.Columns.Add("LineTotal", typeof(decimal));

            dgvInvoiceItems.DataSource = dtInvoiceItems;

            dgvInvoiceItems.Columns["ProductID"].HeaderText = "کد کالا";
            dgvInvoiceItems.Columns["productName"].HeaderText = "نام کالا";
            dgvInvoiceItems.Columns["Quantity"].HeaderText = "تعداد";
            dgvInvoiceItems.Columns["UnitPrice"].HeaderText = "قیمت واحد";
            dgvInvoiceItems.Columns["LineTotal"].HeaderText = "قیمت کل";

            dgvInvoiceItems.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvInvoiceItems.ReadOnly = true;
            dgvInvoiceItems.AllowUserToAddRows = false;

            lblTotalAmount.Text = "0";
            txtTotalAmount.Text = lblTotalAmount.Text;
            txtDiscountAmount.Text = "0";
            txtUser.Text = "شیرین رضایی";
            
        }

        private void btnMashinHesab_Click(object sender, EventArgs e)
        {
            FrmCalculator frmCalculator = new FrmCalculator();
            frmCalculator.Show();
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtProductID.Text.Trim() == "" ||
            txtProductName.Text.Trim() == "" ||
            txtQty.Text.Trim() == "" ||
            txtUnitPrice.Text.Trim() == "")
                {
                    MessageBox.Show("لطفاً اطلاعات کالا را کامل وارد کنید");
                    return;
                }

                int ProductID = int.Parse(txtProductID.Text);
                string productName = txtProductName.Text;
                decimal Quantity = decimal.Parse(txtQty.Text);
                decimal UnitPrice = decimal.Parse(txtUnitPrice.Text);
                decimal LineTotal = Quantity * UnitPrice;

                dtInvoiceItems.Rows.Add(ProductID, productName, Quantity, UnitPrice, LineTotal);

                CalculateTotal();
                
                txtProductID.Clear();
                txtProductName.Clear();
                txtQty.Clear();
                txtUnitPrice.Clear();
                
                txtProductID.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در افزودن کالا: " + ex.Message);
            }
        }

        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            if (dgvInvoiceItems.CurrentRow != null)
            {
                int rowIndex = dgvInvoiceItems.CurrentRow.Index;

                if (rowIndex >= 0)
                {
                    dtInvoiceItems.Rows.RemoveAt(rowIndex);
                    CalculateTotal();
                }
            }
        }

        private void btnSaveInvoice_Click(object sender, EventArgs e)
        {
           
            ClsMethods clsmethod = new ClsMethods();
            if (dtInvoiceItems.Rows.Count == 0)
            {
                MessageBox.Show("فاکتور خالی است!");
                return;

            }
            if(txtCustomerName.Text=="")
            {
                MessageBox.Show("لطفا نام خانوادگی مشتری را وارد کنید");
                txtCustomerName.Focus();
                return;
            }
            DateTime InvoiceDate = DateTime.Now;
            string LastName = txtCustomerName.Text;
            int TotalAmount = int.Parse(txtTotalAmount.Text);           
            int DiscountAmount = int.Parse(txtDiscountAmount.Text);
            int FinalAmount = TotalAmount - DiscountAmount;
            int UserID = 2;
            int InvoiceID= clsmethod.Insert_Invoice(InvoiceDate, LastName, TotalAmount, DiscountAmount, FinalAmount, UserID);
            MessageBox.Show(txtTotalAmount.Text);
            foreach (DataRow row in dtInvoiceItems.Rows)
            {
                clsmethod.Insert_SalesInvoiceItem(InvoiceID, row);
            }
            MessageBox.Show("فاکتور با موفقیت ذخیره شد");
            // آماده‌سازی فاکتور بعدی
            dtInvoiceItems.Clear();
            dgvInvoiceItems.DataSource = dtInvoiceItems;
            lblTotalAmount.Text = "0";
            txtNamayeshi.Clear();
            txtCustomerName.Clear();
            txtTotalAmount.Clear();
            txtDiscountAmount.Clear();
            InvoiceID += 1;
            txtInvoicID.Text = InvoiceID.ToString();
           
        }

        private void btnNewInvoice_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button35_Click(object sender, EventArgs e)
        {

        }

        private void btnTokhmehSiah_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "تخمه گل آفتاب";
            txtProductID.Text = "7";
            txtUnitPrice.Text = "8200000";

        }

        private void btnKadoo_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "تخمه کدو";
            txtProductID.Text = "9";
            txtUnitPrice.Text = "9500000";
        }

        private void btnJaponi_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "تخمه ژاپنی";
            txtProductID.Text = "10";
            txtUnitPrice.Text = "9800000";
        }

        private void btnNokhod_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "نخود";
            txtProductID.Text = "14";
            txtUnitPrice.Text = "4500000";
        }

        private void btnLobiasefid_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "لوبیا سفید";
            txtProductID.Text = "16";
            txtUnitPrice.Text = "5600000";
        }

        private void btnAdas_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "عدس";
            txtProductID.Text = "17";
            txtUnitPrice.Text = "4800000";
        }

        private void btnLobiachiti_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "لوبیا چیتی";
            txtProductID.Text = "18";
            txtUnitPrice.Text = "8300000";
        }

        private void btnLobiaghermez_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "لوبیا قرمز";
            txtProductID.Text = "21";
            txtUnitPrice.Text = "6200000";
        }

        private void btnLobiabolboli_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "لوبیا چشم بلبی";
            txtProductID.Text = "22";
            txtUnitPrice.Text = "7200000";
        }

        private void btnBerenghashemi_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "برنج هاشمی";
            txtProductID.Text = "23";
            txtUnitPrice.Text = "5500000";
        }

        private void btnBerenjanbar_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "برنج عنبربو";
            txtProductID.Text = "24";
            txtUnitPrice.Text = "3200000";
        }

        private void btnBerenghendi_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "برنج هندی";
            txtProductID.Text = "25";
            txtUnitPrice.Text = "2800000";
        }

        private void btnZoghaljakson_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "زغال جکسون";
            txtProductID.Text = "26";
            txtUnitPrice.Text = "1800000";
        }

        private void btnZoghalbaloot_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "زغال بلوط";
            txtProductID.Text = "27";
            txtUnitPrice.Text = "800000";
        }

        private void btnZoghallimo_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "زغال لیمو";
            txtProductID.Text = "28";
            txtUnitPrice.Text = "4000000";
        }

        private void btnTokhmemorgh_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "تخم مرغ";
            txtProductID.Text = "29";
            txtUnitPrice.Text = "3200000";
        }

        private void btnGahve_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "قهوه";
            txtProductID.Text = "31";
            txtUnitPrice.Text = "32000000";
        }

        private void btnkakao_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "کاکائو";
            txtProductID.Text = "32";
            txtUnitPrice.Text = "40000000";
        }

        private void btn1n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "1";
        }

        private void btn2n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "2";
        }

        private void btn3n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "3";
        }

        private void btn4n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "4";
        }

        private void btn5n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "5";
        }

        private void btn6n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "6";
        }

        private void btn7n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "7";
        }

        private void btn8n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "8";
        }

        private void btn9n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "9";
        }

        private void btn0n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "0";
        }

        private void btn00n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "00";
        }

        private void btn000n_Click(object sender, EventArgs e)
        {
            txtNamayeshi.Text = txtNamayeshi.Text + "000";
        }

        private void btnAddn_Click(object sender, EventArgs e)
        {
            txtUnitPrice.Text = txtNamayeshi.Text;
        }

        private void btnNaghdi_Click(object sender, EventArgs e)
        {
            FrmNaghdi frmnaghdi = new FrmNaghdi();
            frmnaghdi.Show();
        }

        private void btnKharidSarie_Click(object sender, EventArgs e)
        {
            FrmNaghdi frmnaghdi = new FrmNaghdi();
            frmnaghdi.Show();
        }

        private void txtBarcodeDisplay_Click(object sender, EventArgs e)
        {
           
        }

        private void txtBarcodeDisplay_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSaveFactor_Click(object sender, EventArgs e)
        {
            FrmSalesInvoiceItems frms = new FrmSalesInvoiceItems();
            frms.Show();
        }

        //private void button1_Click(object sender, EventArgs e)
        //{

        //}

        //private void button6_Click(object sender, EventArgs e)
        //{

        //}

        //private void button4_Click(object sender, EventArgs e)
        //{

        //}
    }
        
       
            
       

}
