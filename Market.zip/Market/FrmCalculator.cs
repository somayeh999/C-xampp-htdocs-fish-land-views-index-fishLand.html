﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmCalculator : Form
    {
        public FrmCalculator()
        {
            InitializeComponent();
        }

        private void FrmCalculator_Load(object sender, EventArgs e)
        {
          
    }
        double Result1, Result2, Sum, Mul, Min, Div;

        Boolean OPMul, OPSum, OPMin, OPDiv;
        private void btn1_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtResult.Text + "1";

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtResult.Text + "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtResult.Text + "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtResult.Text + "4";
        }

       

        private void btn5_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtResult.Text + "5";
        }

       

        private void btn6_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtResult.Text + "6";
        }

       

        private void btn7_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtResult.Text + "7";
        }

       

        private void btn8_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtResult.Text + "8";
        }

        private void txtResult_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtResult.Text + "9";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            txtResult.Text = txtResult.Text + "0";
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            txtResult.Text = "";
        }

        private void btnMul_Click(object sender, EventArgs e)
        {
            if (txtResult.Text != "")
            {
                Result1 = double.Parse(txtResult.Text);
                txtResult.Text = "";
                OPMul = true;
            }
           
            }
        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (txtResult.Text != "")
            {
                Result1 = double.Parse(txtResult.Text);
                txtResult.Text = "";
                OPDiv = true;
            }

        }
        private void btnMin_Click(object sender, EventArgs e)
        {
            if (txtResult.Text != "")
            {
                Result1 = double.Parse(txtResult.Text);
                txtResult.Text = "";
                OPMin = true;
            }
        }
        private void btnSum_Click(object sender, EventArgs e)
        {
            if (txtResult.Text != "")
            {
                Result1 = double.Parse(txtResult.Text);
                txtResult.Text = "";
                OPSum = true;
            }
        }
        private void btnR_Click(object sender, EventArgs e)
        {
            if (txtResult.Text != "")
            {
                Result2 = double.Parse(txtResult.Text);
                if (OPSum == true)
                {
                    Sum = Result1 + Result2;
                    txtResult.Text = Sum.ToString();
                    OPSum = false;
                }
                else if (OPMin == true)
                {
                    Min = Result1 - Result2;
                    txtResult.Text = Min.ToString();
                    OPMin = false;
                }
                else if (OPMul == true)
                {
                    Mul = (Result1 * Result2);
                    txtResult.Text = Mul.ToString();
                    OPMul = false;
                }
                else if (OPDiv == true)
                {
                    Div = Result1 / Result2;
                    txtResult.Text = Div.ToString();
                    OPDiv = false;
                }
            }
        }
    }
}
