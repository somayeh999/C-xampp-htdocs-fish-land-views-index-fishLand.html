﻿
namespace Market
{
    partial class FrmStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSabt = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.StockID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastUpdated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinStockLevel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblStockID = new System.Windows.Forms.Label();
            this.lblProductID = new System.Windows.Forms.Label();
            this.lblLstUpdate = new System.Windows.Forms.Label();
            this.lblMini = new System.Windows.Forms.Label();
            this.txtStockID = new System.Windows.Forms.TextBox();
            this.txtProductID = new System.Windows.Forms.TextBox();
            this.txtUp = new System.Windows.Forms.TextBox();
            this.txtMini = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSabt
            // 
            this.btnSabt.BackColor = System.Drawing.Color.LightGreen;
            this.btnSabt.Image = global::Market.Properties.Resources.add_item1;
            this.btnSabt.Location = new System.Drawing.Point(34, 222);
            this.btnSabt.Name = "btnSabt";
            this.btnSabt.Size = new System.Drawing.Size(104, 33);
            this.btnSabt.TabIndex = 9;
            this.btnSabt.Text = "ثبت";
            this.btnSabt.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnSabt.UseVisualStyleBackColor = false;
            this.btnSabt.Click += new System.EventHandler(this.btnSabt_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.SeaShell;
            this.btnEdit.Image = global::Market.Properties.Resources.edit_item1;
            this.btnEdit.Location = new System.Drawing.Point(303, 222);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(104, 33);
            this.btnEdit.TabIndex = 10;
            this.btnEdit.Text = "ویرایش";
            this.btnEdit.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Tomato;
            this.btnDelete.Image = global::Market.Properties.Resources.delete_item1;
            this.btnDelete.Location = new System.Drawing.Point(144, 222);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(104, 33);
            this.btnDelete.TabIndex = 11;
            this.btnDelete.Text = "حذف";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Image = global::Market.Properties.Resources.search_magnifier1;
            this.btnSearch.Location = new System.Drawing.Point(413, 222);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(104, 33);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.Text = "جستجو";
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.StockID,
            this.ProductID,
            this.Quantity,
            this.LastUpdated,
            this.MinStockLevel});
            this.dataGridView1.Location = new System.Drawing.Point(34, 273);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(483, 250);
            this.dataGridView1.TabIndex = 13;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // StockID
            // 
            this.StockID.DataPropertyName = "StockID";
            this.StockID.HeaderText = "کد";
            this.StockID.Name = "StockID";
            this.StockID.Width = 40;
            // 
            // ProductID
            // 
            this.ProductID.DataPropertyName = "ProductID";
            this.ProductID.HeaderText = "کدمحصول";
            this.ProductID.Name = "ProductID";
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.HeaderText = "تعداد موجود";
            this.Quantity.Name = "Quantity";
            // 
            // LastUpdated
            // 
            this.LastUpdated.DataPropertyName = "LastUpdated";
            this.LastUpdated.HeaderText = "به روز رسانی";
            this.LastUpdated.Name = "LastUpdated";
            // 
            // MinStockLevel
            // 
            this.MinStockLevel.DataPropertyName = "MinStockLevel";
            this.MinStockLevel.HeaderText = "حداقل";
            this.MinStockLevel.Name = "MinStockLevel";
            // 
            // lblStockID
            // 
            this.lblStockID.AutoSize = true;
            this.lblStockID.Location = new System.Drawing.Point(31, 21);
            this.lblStockID.Name = "lblStockID";
            this.lblStockID.Size = new System.Drawing.Size(28, 17);
            this.lblStockID.TabIndex = 14;
            this.lblStockID.Text = "کد بار";
            // 
            // lblProductID
            // 
            this.lblProductID.AutoSize = true;
            this.lblProductID.Location = new System.Drawing.Point(239, 21);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(44, 17);
            this.lblProductID.TabIndex = 15;
            this.lblProductID.Text = "کدمحصول";
            // 
            // lblLstUpdate
            // 
            this.lblLstUpdate.AutoSize = true;
            this.lblLstUpdate.Location = new System.Drawing.Point(31, 110);
            this.lblLstUpdate.Name = "lblLstUpdate";
            this.lblLstUpdate.Size = new System.Drawing.Size(52, 17);
            this.lblLstUpdate.TabIndex = 16;
            this.lblLstUpdate.Text = "به روز رسانی";
            // 
            // lblMini
            // 
            this.lblMini.AutoSize = true;
            this.lblMini.Location = new System.Drawing.Point(239, 110);
            this.lblMini.Name = "lblMini";
            this.lblMini.Size = new System.Drawing.Size(31, 17);
            this.lblMini.TabIndex = 17;
            this.lblMini.Text = "حداقل";
            // 
            // txtStockID
            // 
            this.txtStockID.Location = new System.Drawing.Point(34, 41);
            this.txtStockID.Name = "txtStockID";
            this.txtStockID.Size = new System.Drawing.Size(156, 24);
            this.txtStockID.TabIndex = 18;
            // 
            // txtProductID
            // 
            this.txtProductID.Location = new System.Drawing.Point(217, 41);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.Size = new System.Drawing.Size(156, 24);
            this.txtProductID.TabIndex = 19;
            // 
            // txtUp
            // 
            this.txtUp.Location = new System.Drawing.Point(34, 130);
            this.txtUp.Name = "txtUp";
            this.txtUp.Size = new System.Drawing.Size(156, 24);
            this.txtUp.TabIndex = 20;
            // 
            // txtMini
            // 
            this.txtMini.Location = new System.Drawing.Point(217, 130);
            this.txtMini.Name = "txtMini";
            this.txtMini.Size = new System.Drawing.Size(156, 24);
            this.txtMini.TabIndex = 21;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(392, 12);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(152, 24);
            this.dateTimePicker1.TabIndex = 22;
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(398, 110);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(50, 17);
            this.lblQuantity.TabIndex = 23;
            this.lblQuantity.Text = "تعداد موجود";
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(392, 130);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(152, 24);
            this.txtQuantity.TabIndex = 24;
            // 
            // FrmStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(556, 535);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtMini);
            this.Controls.Add(this.txtUp);
            this.Controls.Add(this.txtProductID);
            this.Controls.Add(this.txtStockID);
            this.Controls.Add(this.lblMini);
            this.Controls.Add(this.lblLstUpdate);
            this.Controls.Add(this.lblProductID);
            this.Controls.Add(this.lblStockID);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnSabt);
            this.Font = new System.Drawing.Font("B Nazanin", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmStock";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "موجودی انبار";
            this.Load += new System.EventHandler(this.FrmStock_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSabt;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn StockID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastUpdated;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinStockLevel;
        private System.Windows.Forms.Label lblStockID;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.Label lblLstUpdate;
        private System.Windows.Forms.Label lblMini;
        private System.Windows.Forms.TextBox txtStockID;
        private System.Windows.Forms.TextBox txtProductID;
        private System.Windows.Forms.TextBox txtUp;
        private System.Windows.Forms.TextBox txtMini;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.TextBox txtQuantity;
    }
}