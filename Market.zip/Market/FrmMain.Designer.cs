﻿
namespace Market
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.مدیریتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.کاربرانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.نقشهاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.دسترسیهاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تغییردسترسیکاربرانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.محصولاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.محصولاتToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.شرکتهایتامینکنندهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انبارToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فاکتورهایفروشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جزییاتفاکتورToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.راهنماToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.دربارهماToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblForooshgah = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.MediumTurquoise;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مدیریتToolStripMenuItem,
            this.محصولاتToolStripMenuItem,
            this.گزارشاتToolStripMenuItem,
            this.راهنماToolStripMenuItem,
            this.دربارهماToolStripMenuItem,
            this.خروجToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(800, 40);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // مدیریتToolStripMenuItem
            // 
            this.مدیریتToolStripMenuItem.AutoSize = false;
            this.مدیریتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.کاربرانToolStripMenuItem,
            this.نقشهاToolStripMenuItem,
            this.دسترسیهاToolStripMenuItem,
            this.تغییردسترسیکاربرانToolStripMenuItem});
            this.مدیریتToolStripMenuItem.Name = "مدیریتToolStripMenuItem";
            this.مدیریتToolStripMenuItem.Size = new System.Drawing.Size(90, 36);
            this.مدیریتToolStripMenuItem.Text = "مدیریت";
            // 
            // کاربرانToolStripMenuItem
            // 
            this.کاربرانToolStripMenuItem.Name = "کاربرانToolStripMenuItem";
            this.کاربرانToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.کاربرانToolStripMenuItem.Text = "کاربران";
            this.کاربرانToolStripMenuItem.Click += new System.EventHandler(this.کاربرانToolStripMenuItem_Click);
            // 
            // نقشهاToolStripMenuItem
            // 
            this.نقشهاToolStripMenuItem.Name = "نقشهاToolStripMenuItem";
            this.نقشهاToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.نقشهاToolStripMenuItem.Text = "نقش ها";
            this.نقشهاToolStripMenuItem.Click += new System.EventHandler(this.نقشهاToolStripMenuItem_Click);
            // 
            // دسترسیهاToolStripMenuItem
            // 
            this.دسترسیهاToolStripMenuItem.Name = "دسترسیهاToolStripMenuItem";
            this.دسترسیهاToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.دسترسیهاToolStripMenuItem.Text = "دسترسی ها";
            this.دسترسیهاToolStripMenuItem.Click += new System.EventHandler(this.دسترسیهاToolStripMenuItem_Click);
            // 
            // تغییردسترسیکاربرانToolStripMenuItem
            // 
            this.تغییردسترسیکاربرانToolStripMenuItem.Name = "تغییردسترسیکاربرانToolStripMenuItem";
            this.تغییردسترسیکاربرانToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.تغییردسترسیکاربرانToolStripMenuItem.Text = "تغییر دسترسی کاربران";
            this.تغییردسترسیکاربرانToolStripMenuItem.Click += new System.EventHandler(this.تغییردسترسیکاربرانToolStripMenuItem_Click);
            // 
            // محصولاتToolStripMenuItem
            // 
            this.محصولاتToolStripMenuItem.AutoSize = false;
            this.محصولاتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.محصولاتToolStripMenuItem1,
            this.شرکتهایتامینکنندهToolStripMenuItem,
            this.انبارToolStripMenuItem});
            this.محصولاتToolStripMenuItem.Name = "محصولاتToolStripMenuItem";
            this.محصولاتToolStripMenuItem.Size = new System.Drawing.Size(90, 36);
            this.محصولاتToolStripMenuItem.Text = "محصولات";
            // 
            // محصولاتToolStripMenuItem1
            // 
            this.محصولاتToolStripMenuItem1.Name = "محصولاتToolStripMenuItem1";
            this.محصولاتToolStripMenuItem1.Size = new System.Drawing.Size(185, 22);
            this.محصولاتToolStripMenuItem1.Text = "محصولات";
            this.محصولاتToolStripMenuItem1.Click += new System.EventHandler(this.محصولاتToolStripMenuItem1_Click);
            // 
            // شرکتهایتامینکنندهToolStripMenuItem
            // 
            this.شرکتهایتامینکنندهToolStripMenuItem.Name = "شرکتهایتامینکنندهToolStripMenuItem";
            this.شرکتهایتامینکنندهToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.شرکتهایتامینکنندهToolStripMenuItem.Text = "شرکت های تامین کننده";
            this.شرکتهایتامینکنندهToolStripMenuItem.Click += new System.EventHandler(this.شرکتهایتامینکنندهToolStripMenuItem_Click);
            // 
            // انبارToolStripMenuItem
            // 
            this.انبارToolStripMenuItem.Name = "انبارToolStripMenuItem";
            this.انبارToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.انبارToolStripMenuItem.Text = "انبار";
            this.انبارToolStripMenuItem.Click += new System.EventHandler(this.انبارToolStripMenuItem_Click);
            // 
            // گزارشاتToolStripMenuItem
            // 
            this.گزارشاتToolStripMenuItem.AutoSize = false;
            this.گزارشاتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.فاکتورهایفروشToolStripMenuItem,
            this.جزییاتفاکتورToolStripMenuItem});
            this.گزارشاتToolStripMenuItem.Name = "گزارشاتToolStripMenuItem";
            this.گزارشاتToolStripMenuItem.Size = new System.Drawing.Size(100, 36);
            this.گزارشاتToolStripMenuItem.Text = "گزارشات";
            // 
            // فاکتورهایفروشToolStripMenuItem
            // 
            this.فاکتورهایفروشToolStripMenuItem.Name = "فاکتورهایفروشToolStripMenuItem";
            this.فاکتورهایفروشToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.فاکتورهایفروشToolStripMenuItem.Text = "فاکتورهای فروش";
            this.فاکتورهایفروشToolStripMenuItem.Click += new System.EventHandler(this.فاکتورهایفروشToolStripMenuItem_Click);
            // 
            // جزییاتفاکتورToolStripMenuItem
            // 
            this.جزییاتفاکتورToolStripMenuItem.Name = "جزییاتفاکتورToolStripMenuItem";
            this.جزییاتفاکتورToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.جزییاتفاکتورToolStripMenuItem.Text = "جزییات فاکتور";
            this.جزییاتفاکتورToolStripMenuItem.Click += new System.EventHandler(this.جزییاتفاکتورToolStripMenuItem_Click);
            // 
            // راهنماToolStripMenuItem
            // 
            this.راهنماToolStripMenuItem.AutoSize = false;
            this.راهنماToolStripMenuItem.Name = "راهنماToolStripMenuItem";
            this.راهنماToolStripMenuItem.Size = new System.Drawing.Size(80, 36);
            this.راهنماToolStripMenuItem.Text = "راهنما";
            // 
            // دربارهماToolStripMenuItem
            // 
            this.دربارهماToolStripMenuItem.AutoSize = false;
            this.دربارهماToolStripMenuItem.Name = "دربارهماToolStripMenuItem";
            this.دربارهماToolStripMenuItem.Size = new System.Drawing.Size(80, 36);
            this.دربارهماToolStripMenuItem.Text = "درباره ما";
            // 
            // خروجToolStripMenuItem
            // 
            this.خروجToolStripMenuItem.AutoSize = false;
            this.خروجToolStripMenuItem.Name = "خروجToolStripMenuItem";
            this.خروجToolStripMenuItem.Size = new System.Drawing.Size(80, 36);
            this.خروجToolStripMenuItem.Text = "خروج";
            this.خروجToolStripMenuItem.Click += new System.EventHandler(this.خروجToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Market.Properties.Resources._6a37691a_cef4_411d_802b_93167bfdbe90;
            this.pictureBox1.Location = new System.Drawing.Point(0, 40);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 410);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // lblForooshgah
            // 
            this.lblForooshgah.AutoSize = true;
            this.lblForooshgah.Font = new System.Drawing.Font("B Jadid", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblForooshgah.Location = new System.Drawing.Point(22, 100);
            this.lblForooshgah.Name = "lblForooshgah";
            this.lblForooshgah.Size = new System.Drawing.Size(191, 54);
            this.lblForooshgah.TabIndex = 8;
            this.lblForooshgah.Text = "هایپر آل سن";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblForooshgah);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmMain";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "مدیریت";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem مدیریتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem محصولاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem راهنماToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem دربارهماToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem کاربرانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem نقشهاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem دسترسیهاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تغییردسترسیکاربرانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem محصولاتToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem شرکتهایتامینکنندهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انبارToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فاکتورهایفروشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem جزییاتفاکتورToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblForooshgah;
    }
}