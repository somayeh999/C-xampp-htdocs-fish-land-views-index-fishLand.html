﻿using System;
using System.Collections.Generic; // این خط را برای List لازم دارید
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq; // این خط را برای FirstOrDefault لازم دارید
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Market
{
    public partial class FrmUsers : Form
    {
        public FrmUsers()
        {
            InitializeComponent();
        }
        int UserID1 = -1;
        private void FrmUsers_Load(object sender, EventArgs e)
        {
            ClsMethods clsUser = new ClsMethods();
            dataGridView1.DataSource = clsUser.kolUsers();
        }

        private void btnSabt_Click(object sender, EventArgs e)
        {
            if(txtUsername.Text=="")
            {
                MessageBox.Show("لطفا نام کاربری را وارد کنید");
                txtUsername.Focus();
                return;
            }
            if(txtPass.Text=="")
            {
                MessageBox.Show("لطفا رمز عبور را وارد کنید");
                txtPass.Focus();
                return;
            }
            if(txtName.Text=="")
            {
                MessageBox.Show("لطفا نام کامل کاربر را وارد کنید");
                txtName.Focus();
                return;
            }
            if(txtIDRole.Text=="")
            {
                MessageBox.Show("لطفا کد نقش را وارد کنید");
                txtIDRole.Focus();
                return;
            }
            int idrole;
            if(int.TryParse(txtIDRole.Text,out idrole)==false)
            {
                MessageBox.Show("لطفا کد نقش را بصورت عدد صحیح وارد کنید");
                txtIDRole.Text = "";
                txtIDRole.Focus();
                return;
            }
            if(rdbTrue.Checked==false && rdbFalse.Checked==false)
            {
                MessageBox.Show("لطفا فعال بودن یا غیر فعال بودن کاربر را مشخص کنید");
                return;
            }
            ClsMethods clsuser = new ClsMethods();
            string UserName = txtUsername.Text;
            string PasswordHash = txtPass.Text;
            string FullName = txtName.Text;
            int RoleID = idrole;
            bool IsActive;
            if (rdbTrue.Checked)
            {
                 IsActive = true;
            }
            else if(rdbFalse.Checked)
            {
                IsActive = false;
            }
            else
            {
                IsActive = false;
            }
            clsuser.Insert_User(UserName, PasswordHash, FullName, RoleID, IsActive);
            MessageBox.Show("اطلاعات با موفقیت ذخیره شد");
            dataGridView1.DataSource = clsuser.kolUsers();
            txtIDRole.Text = txtName.Text = txtPass.Text = txtUsername.Text = "";
            rdbFalse.Checked = false;
            rdbTrue.Checked = false;
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            DataRowView drv = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
            txtUsername.Text = drv["UserName"].ToString();
            txtPass.Text = drv["PasswordHash"].ToString();
            txtName.Text = drv["FullName"].ToString();
            txtIDRole.Text = drv["RoleID"].ToString();
            bool isActive = Convert.ToBoolean(drv["IsActive"]);
            rdbTrue.Checked = isActive;
            rdbFalse.Checked = !isActive;
            UserID1 = (int)drv["UserID"];
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            ClsMethods clsuser = new ClsMethods();
            string UserName = txtUsername.Text;
            string PasswordHash = txtPass.Text;
            string FullName = txtName.Text;
            
            int RoleID = int.Parse(txtIDRole.Text);
            bool IsActive;
            if (rdbTrue.Checked)
            {
                IsActive = true;
            }
            else if (rdbFalse.Checked)
            {
                IsActive = false;
            }
            else
            {
                IsActive = false;
            }
            clsuser.Update_User(UserID1, UserName, PasswordHash, FullName, RoleID, IsActive);
            MessageBox.Show("اطلاعات با موفقیت ویرایش شد");
            dataGridView1.DataSource = clsuser.kolUsers();
            txtIDRole.Text = txtName.Text = txtPass.Text = txtUsername.Text = "";
            rdbFalse.Checked = false;
            rdbTrue.Checked = false;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
                return;
            ClsMethods clsuser = new ClsMethods();
            DialogResult result = MessageBox.Show("آیا از حذف این کاربر اطمینان دارید", "توجه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                clsuser.Delete_User(UserID1);
                dataGridView1.DataSource = clsuser.kolUsers();
                txtIDRole.Text = txtName.Text = txtPass.Text = txtUsername.Text = "";
                rdbFalse.Checked = false;
                rdbTrue.Checked = false;
            }
        }
    }
}
