﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmSalesInvoices : Form
    {
        public FrmSalesInvoices()
        {
            InitializeComponent();
        }

        private void FrmSalesInvoices_Load(object sender, EventArgs e)
        {
            ClsMethods clsSalesInvoic = new ClsMethods();
            dataGridView1.DataSource = clsSalesInvoic.kolSalesInvoices();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
           
                ClsMethods m = new ClsMethods();

                DataTable dt = m.ReportDailySales(dtpDate.Value);

                dataGridView1.DataSource = dt;

                lblTotalInvoice.Text = dt.Rows.Count.ToString();

                int sum = 0;

                foreach (DataRow row in dt.Rows)
                {
                    sum += Convert.ToInt32(row["FinalAmount"]);
                }

                lblTotalSalse.Text = sum.ToString("N0");
            
        }
    }
}
