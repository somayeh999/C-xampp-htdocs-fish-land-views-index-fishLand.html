﻿
namespace Market
{
    partial class FrmForoosh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmForoosh));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl2TotalAmount = new System.Windows.Forms.Label();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.txtDiscountAmount = new System.Windows.Forms.TextBox();
            this.lblDiscountAmount = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.lblForooshgah = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.lblUser = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtNamayeshi = new System.Windows.Forms.TextBox();
            this.btnErsalPeik = new System.Windows.Forms.Button();
            this.btnNesieh = new System.Windows.Forms.Button();
            this.btnNaghdi = new System.Windows.Forms.Button();
            this.btnKarti = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btnNantanoori = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnZoghallimo = new System.Windows.Forms.Button();
            this.btnZoghalbaloot = new System.Windows.Forms.Button();
            this.btnLobiasefid = new System.Windows.Forms.Button();
            this.btnAdas = new System.Windows.Forms.Button();
            this.btnLobiabolboli = new System.Windows.Forms.Button();
            this.btnBerenghendi = new System.Windows.Forms.Button();
            this.btnBerenjanbar = new System.Windows.Forms.Button();
            this.btnLobiaghermez = new System.Windows.Forms.Button();
            this.btnZoghaljakson = new System.Windows.Forms.Button();
            this.btnkakao = new System.Windows.Forms.Button();
            this.btnGahve = new System.Windows.Forms.Button();
            this.btnTokhmemorgh = new System.Windows.Forms.Button();
            this.btnNokhod = new System.Windows.Forms.Button();
            this.btnLobiachiti = new System.Windows.Forms.Button();
            this.btnBerenghashemi = new System.Windows.Forms.Button();
            this.btnKadoo = new System.Windows.Forms.Button();
            this.btnJaponi = new System.Windows.Forms.Button();
            this.btnTokhmehSiah = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnJambon = new System.Windows.Forms.Button();
            this.btnKalbasgharch = new System.Windows.Forms.Button();
            this.btnKalbaskhoshk = new System.Windows.Forms.Button();
            this.btnKalbasgoosht = new System.Windows.Forms.Button();
            this.btnKalbaspeste = new System.Windows.Forms.Button();
            this.btnKoktel = new System.Windows.Forms.Button();
            this.btnNanrejimi = new System.Windows.Forms.Button();
            this.btnNansnak = new System.Windows.Forms.Button();
            this.btnNankhoshk = new System.Windows.Forms.Button();
            this.btnNanbaget = new System.Windows.Forms.Button();
            this.btnMinibaget = new System.Windows.Forms.Button();
            this.btnKhoshkehboland = new System.Windows.Forms.Button();
            this.btnMarta = new System.Windows.Forms.Button();
            this.btnKalbasmorgh = new System.Windows.Forms.Button();
            this.btnSosis = new System.Windows.Forms.Button();
            this.btnNanmahali = new System.Windows.Forms.Button();
            this.btnNanlavash = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.btnMashinHesab = new System.Windows.Forms.Button();
            this.btnTarazoo = new System.Windows.Forms.Button();
            this.btnKharidSarie = new System.Windows.Forms.Button();
            this.btnSaveFactor = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.txtBarcodeDisplay = new System.Windows.Forms.TextBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.btnAddn = new System.Windows.Forms.Button();
            this.btn00n = new System.Windows.Forms.Button();
            this.btn000n = new System.Windows.Forms.Button();
            this.btn9n = new System.Windows.Forms.Button();
            this.btn7n = new System.Windows.Forms.Button();
            this.btn0n = new System.Windows.Forms.Button();
            this.btn8n = new System.Windows.Forms.Button();
            this.btn6n = new System.Windows.Forms.Button();
            this.btn4n = new System.Windows.Forms.Button();
            this.btn5n = new System.Windows.Forms.Button();
            this.btn3n = new System.Windows.Forms.Button();
            this.btn1n = new System.Windows.Forms.Button();
            this.btn2n = new System.Windows.Forms.Button();
            this.btnNewInvoice = new System.Windows.Forms.Button();
            this.btnSaveInvoice = new System.Windows.Forms.Button();
            this.btnDeleteItem = new System.Windows.Forms.Button();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.lbltCustomerName = new System.Windows.Forms.Label();
            this.txtProductID = new System.Windows.Forms.TextBox();
            this.lblProductID = new System.Windows.Forms.Label();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblQty = new System.Windows.Forms.Label();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.txtUnitPrice = new System.Windows.Forms.TextBox();
            this.lblUnitPrice = new System.Windows.Forms.Label();
            this.dgvInvoiceItems = new System.Windows.Forms.DataGridView();
            this.lblInvoicID = new System.Windows.Forms.Label();
            this.txtInvoicID = new System.Windows.Forms.TextBox();
            this.btndownT = new System.Windows.Forms.Button();
            this.btnupT = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.btnNantanoori.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoiceItems)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl2TotalAmount);
            this.groupBox1.Controls.Add(this.txtTotalAmount);
            this.groupBox1.Controls.Add(this.txtDiscountAmount);
            this.groupBox1.Controls.Add(this.lblDiscountAmount);
            this.groupBox1.Location = new System.Drawing.Point(714, 534);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(280, 116);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // lbl2TotalAmount
            // 
            this.lbl2TotalAmount.AutoSize = true;
            this.lbl2TotalAmount.Location = new System.Drawing.Point(190, 80);
            this.lbl2TotalAmount.Name = "lbl2TotalAmount";
            this.lbl2TotalAmount.Size = new System.Drawing.Size(78, 18);
            this.lbl2TotalAmount.TabIndex = 3;
            this.lbl2TotalAmount.Text = "مبلغ قابل پرداخت:";
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.Location = new System.Drawing.Point(84, 77);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.Size = new System.Drawing.Size(100, 25);
            this.txtTotalAmount.TabIndex = 2;
            // 
            // txtDiscountAmount
            // 
            this.txtDiscountAmount.Location = new System.Drawing.Point(84, 18);
            this.txtDiscountAmount.Name = "txtDiscountAmount";
            this.txtDiscountAmount.Size = new System.Drawing.Size(100, 25);
            this.txtDiscountAmount.TabIndex = 1;
            // 
            // lblDiscountAmount
            // 
            this.lblDiscountAmount.AutoSize = true;
            this.lblDiscountAmount.Location = new System.Drawing.Point(230, 21);
            this.lblDiscountAmount.Name = "lblDiscountAmount";
            this.lblDiscountAmount.Size = new System.Drawing.Size(37, 18);
            this.lblDiscountAmount.TabIndex = 0;
            this.lblDiscountAmount.Text = "تخفیف:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblTotalAmount);
            this.groupBox2.Font = new System.Drawing.Font("B Homa", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.groupBox2.Location = new System.Drawing.Point(1000, 534);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(181, 116);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "جمع کل";
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.Location = new System.Drawing.Point(46, 56);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(0, 22);
            this.lblTotalAmount.TabIndex = 0;
            // 
            // lblForooshgah
            // 
            this.lblForooshgah.AutoSize = true;
            this.lblForooshgah.Font = new System.Drawing.Font("Badr", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblForooshgah.Location = new System.Drawing.Point(45, 21);
            this.lblForooshgah.Name = "lblForooshgah";
            this.lblForooshgah.Size = new System.Drawing.Size(96, 39);
            this.lblForooshgah.TabIndex = 4;
            this.lblForooshgah.Text = "هایپر آل سن";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblForooshgah);
            this.groupBox3.Controls.Add(this.pictureBox1);
            this.groupBox3.Location = new System.Drawing.Point(14, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(294, 76);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::Market.Properties.Resources._6a37691a_cef4_411d_802b_93167bfdbe90;
            this.pictureBox1.Location = new System.Drawing.Point(164, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(118, 59);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtUser);
            this.groupBox4.Controls.Add(this.lblUser);
            this.groupBox4.Controls.Add(this.dateTimePicker1);
            this.groupBox4.Controls.Add(this.groupBox6);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.groupBox7);
            this.groupBox4.Location = new System.Drawing.Point(318, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(867, 72);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            // 
            // txtUser
            // 
            this.txtUser.Location = new System.Drawing.Point(11, 13);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(100, 25);
            this.txtUser.TabIndex = 10;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(117, 16);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(28, 18);
            this.lblUser.TabIndex = 9;
            this.lblUser.Text = "کاربر:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(6, 41);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(147, 25);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // groupBox6
            // 
            this.groupBox6.Location = new System.Drawing.Point(0, 78);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(437, 65);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Location = new System.Drawing.Point(0, 78);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(918, 57);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "groupBox5";
            // 
            // groupBox7
            // 
            this.groupBox7.Location = new System.Drawing.Point(6, 72);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(440, 77);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtNamayeshi);
            this.groupBox8.Controls.Add(this.btnErsalPeik);
            this.groupBox8.Controls.Add(this.btnNesieh);
            this.groupBox8.Controls.Add(this.btnNaghdi);
            this.groupBox8.Controls.Add(this.btnKarti);
            this.groupBox8.Location = new System.Drawing.Point(312, 75);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(395, 228);
            this.groupBox8.TabIndex = 8;
            this.groupBox8.TabStop = false;
            // 
            // txtNamayeshi
            // 
            this.txtNamayeshi.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtNamayeshi.Location = new System.Drawing.Point(8, 24);
            this.txtNamayeshi.Name = "txtNamayeshi";
            this.txtNamayeshi.Size = new System.Drawing.Size(381, 43);
            this.txtNamayeshi.TabIndex = 4;
            // 
            // btnErsalPeik
            // 
            this.btnErsalPeik.Font = new System.Drawing.Font("B Jadid", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnErsalPeik.Location = new System.Drawing.Point(6, 156);
            this.btnErsalPeik.Name = "btnErsalPeik";
            this.btnErsalPeik.Size = new System.Drawing.Size(188, 67);
            this.btnErsalPeik.TabIndex = 3;
            this.btnErsalPeik.Text = "ارسال با پیک";
            this.btnErsalPeik.UseVisualStyleBackColor = true;
            // 
            // btnNesieh
            // 
            this.btnNesieh.Font = new System.Drawing.Font("B Jadid", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnNesieh.Location = new System.Drawing.Point(200, 156);
            this.btnNesieh.Name = "btnNesieh";
            this.btnNesieh.Size = new System.Drawing.Size(189, 67);
            this.btnNesieh.TabIndex = 2;
            this.btnNesieh.Text = "پرداخت نسیه";
            this.btnNesieh.UseVisualStyleBackColor = true;
            this.btnNesieh.Click += new System.EventHandler(this.button7_Click);
            // 
            // btnNaghdi
            // 
            this.btnNaghdi.Font = new System.Drawing.Font("B Jadid", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnNaghdi.Location = new System.Drawing.Point(6, 83);
            this.btnNaghdi.Name = "btnNaghdi";
            this.btnNaghdi.Size = new System.Drawing.Size(188, 67);
            this.btnNaghdi.TabIndex = 1;
            this.btnNaghdi.Text = "پرداخت نقدی";
            this.btnNaghdi.UseVisualStyleBackColor = true;
            this.btnNaghdi.Click += new System.EventHandler(this.btnNaghdi_Click);
            // 
            // btnKarti
            // 
            this.btnKarti.Font = new System.Drawing.Font("B Jadid", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnKarti.Location = new System.Drawing.Point(200, 83);
            this.btnKarti.Name = "btnKarti";
            this.btnKarti.Size = new System.Drawing.Size(189, 67);
            this.btnKarti.TabIndex = 0;
            this.btnKarti.Text = "پرداخت کارتی";
            this.btnKarti.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btnNantanoori);
            this.groupBox9.Location = new System.Drawing.Point(12, 309);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(294, 337);
            this.groupBox9.TabIndex = 9;
            this.groupBox9.TabStop = false;
            // 
            // btnNantanoori
            // 
            this.btnNantanoori.Controls.Add(this.tabPage1);
            this.btnNantanoori.Controls.Add(this.tabPage2);
            this.btnNantanoori.Controls.Add(this.tabPage3);
            this.btnNantanoori.Font = new System.Drawing.Font("B Nazanin", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnNantanoori.Location = new System.Drawing.Point(6, 24);
            this.btnNantanoori.Name = "btnNantanoori";
            this.btnNantanoori.RightToLeftLayout = true;
            this.btnNantanoori.SelectedIndex = 0;
            this.btnNantanoori.Size = new System.Drawing.Size(286, 307);
            this.btnNantanoori.TabIndex = 11;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FloralWhite;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.btnZoghallimo);
            this.tabPage1.Controls.Add(this.btnZoghalbaloot);
            this.tabPage1.Controls.Add(this.btnLobiasefid);
            this.tabPage1.Controls.Add(this.btnAdas);
            this.tabPage1.Controls.Add(this.btnLobiabolboli);
            this.tabPage1.Controls.Add(this.btnBerenghendi);
            this.tabPage1.Controls.Add(this.btnBerenjanbar);
            this.tabPage1.Controls.Add(this.btnLobiaghermez);
            this.tabPage1.Controls.Add(this.btnZoghaljakson);
            this.tabPage1.Controls.Add(this.btnkakao);
            this.tabPage1.Controls.Add(this.btnGahve);
            this.tabPage1.Controls.Add(this.btnTokhmemorgh);
            this.tabPage1.Controls.Add(this.btnNokhod);
            this.tabPage1.Controls.Add(this.btnLobiachiti);
            this.tabPage1.Controls.Add(this.btnBerenghashemi);
            this.tabPage1.Controls.Add(this.btnKadoo);
            this.tabPage1.Controls.Add(this.btnJaponi);
            this.tabPage1.Controls.Add(this.btnTokhmehSiah);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(278, 274);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "فله";
            // 
            // btnZoghallimo
            // 
            this.btnZoghallimo.Location = new System.Drawing.Point(6, 186);
            this.btnZoghallimo.Name = "btnZoghallimo";
            this.btnZoghallimo.Size = new System.Drawing.Size(85, 36);
            this.btnZoghallimo.TabIndex = 17;
            this.btnZoghallimo.Text = "زغال لیمو";
            this.btnZoghallimo.UseVisualStyleBackColor = true;
            this.btnZoghallimo.Click += new System.EventHandler(this.btnZoghallimo_Click);
            // 
            // btnZoghalbaloot
            // 
            this.btnZoghalbaloot.Location = new System.Drawing.Point(92, 186);
            this.btnZoghalbaloot.Name = "btnZoghalbaloot";
            this.btnZoghalbaloot.Size = new System.Drawing.Size(90, 36);
            this.btnZoghalbaloot.TabIndex = 16;
            this.btnZoghalbaloot.Text = "زغال بلوط";
            this.btnZoghalbaloot.UseVisualStyleBackColor = true;
            this.btnZoghalbaloot.Click += new System.EventHandler(this.btnZoghalbaloot_Click);
            // 
            // btnLobiasefid
            // 
            this.btnLobiasefid.Location = new System.Drawing.Point(92, 61);
            this.btnLobiasefid.Name = "btnLobiasefid";
            this.btnLobiasefid.Size = new System.Drawing.Size(90, 36);
            this.btnLobiasefid.TabIndex = 15;
            this.btnLobiasefid.Text = "لوبیا سفید";
            this.btnLobiasefid.UseVisualStyleBackColor = true;
            this.btnLobiasefid.Click += new System.EventHandler(this.btnLobiasefid_Click);
            // 
            // btnAdas
            // 
            this.btnAdas.Location = new System.Drawing.Point(6, 61);
            this.btnAdas.Name = "btnAdas";
            this.btnAdas.Size = new System.Drawing.Size(85, 36);
            this.btnAdas.TabIndex = 14;
            this.btnAdas.Text = "عدس";
            this.btnAdas.UseVisualStyleBackColor = true;
            this.btnAdas.Click += new System.EventHandler(this.btnAdas_Click);
            // 
            // btnLobiabolboli
            // 
            this.btnLobiabolboli.Location = new System.Drawing.Point(6, 103);
            this.btnLobiabolboli.Name = "btnLobiabolboli";
            this.btnLobiabolboli.Size = new System.Drawing.Size(85, 36);
            this.btnLobiabolboli.TabIndex = 13;
            this.btnLobiabolboli.Text = "لوبیا بلبلی";
            this.btnLobiabolboli.UseVisualStyleBackColor = true;
            this.btnLobiabolboli.Click += new System.EventHandler(this.btnLobiabolboli_Click);
            // 
            // btnBerenghendi
            // 
            this.btnBerenghendi.Location = new System.Drawing.Point(6, 145);
            this.btnBerenghendi.Name = "btnBerenghendi";
            this.btnBerenghendi.Size = new System.Drawing.Size(85, 36);
            this.btnBerenghendi.TabIndex = 12;
            this.btnBerenghendi.Text = "برنج هندی";
            this.btnBerenghendi.UseVisualStyleBackColor = true;
            this.btnBerenghendi.Click += new System.EventHandler(this.btnBerenghendi_Click);
            // 
            // btnBerenjanbar
            // 
            this.btnBerenjanbar.Location = new System.Drawing.Point(92, 145);
            this.btnBerenjanbar.Name = "btnBerenjanbar";
            this.btnBerenjanbar.Size = new System.Drawing.Size(90, 36);
            this.btnBerenjanbar.TabIndex = 11;
            this.btnBerenjanbar.Text = "برنج عنبربو";
            this.btnBerenjanbar.UseVisualStyleBackColor = true;
            this.btnBerenjanbar.Click += new System.EventHandler(this.btnBerenjanbar_Click);
            // 
            // btnLobiaghermez
            // 
            this.btnLobiaghermez.Location = new System.Drawing.Point(92, 103);
            this.btnLobiaghermez.Name = "btnLobiaghermez";
            this.btnLobiaghermez.Size = new System.Drawing.Size(90, 36);
            this.btnLobiaghermez.TabIndex = 10;
            this.btnLobiaghermez.Text = "لوبیا قرمز";
            this.btnLobiaghermez.UseVisualStyleBackColor = true;
            this.btnLobiaghermez.Click += new System.EventHandler(this.btnLobiaghermez_Click);
            // 
            // btnZoghaljakson
            // 
            this.btnZoghaljakson.Location = new System.Drawing.Point(183, 186);
            this.btnZoghaljakson.Name = "btnZoghaljakson";
            this.btnZoghaljakson.Size = new System.Drawing.Size(85, 36);
            this.btnZoghaljakson.TabIndex = 9;
            this.btnZoghaljakson.Text = "زغال جکسون";
            this.btnZoghaljakson.UseVisualStyleBackColor = true;
            this.btnZoghaljakson.Click += new System.EventHandler(this.btnZoghaljakson_Click);
            // 
            // btnkakao
            // 
            this.btnkakao.Location = new System.Drawing.Point(6, 229);
            this.btnkakao.Name = "btnkakao";
            this.btnkakao.Size = new System.Drawing.Size(85, 36);
            this.btnkakao.TabIndex = 8;
            this.btnkakao.Text = "شکلات کاکائو";
            this.btnkakao.UseVisualStyleBackColor = true;
            this.btnkakao.Click += new System.EventHandler(this.btnkakao_Click);
            // 
            // btnGahve
            // 
            this.btnGahve.Location = new System.Drawing.Point(92, 228);
            this.btnGahve.Name = "btnGahve";
            this.btnGahve.Size = new System.Drawing.Size(90, 36);
            this.btnGahve.TabIndex = 7;
            this.btnGahve.Text = "شکلات قهوه";
            this.btnGahve.UseVisualStyleBackColor = true;
            this.btnGahve.Click += new System.EventHandler(this.btnGahve_Click);
            // 
            // btnTokhmemorgh
            // 
            this.btnTokhmemorgh.Location = new System.Drawing.Point(183, 228);
            this.btnTokhmemorgh.Name = "btnTokhmemorgh";
            this.btnTokhmemorgh.Size = new System.Drawing.Size(85, 36);
            this.btnTokhmemorgh.TabIndex = 6;
            this.btnTokhmemorgh.Text = "تخم مرغ سیمرغ";
            this.btnTokhmemorgh.UseVisualStyleBackColor = true;
            this.btnTokhmemorgh.Click += new System.EventHandler(this.btnTokhmemorgh_Click);
            // 
            // btnNokhod
            // 
            this.btnNokhod.Location = new System.Drawing.Point(183, 61);
            this.btnNokhod.Name = "btnNokhod";
            this.btnNokhod.Size = new System.Drawing.Size(85, 36);
            this.btnNokhod.TabIndex = 5;
            this.btnNokhod.Text = "نخود";
            this.btnNokhod.UseVisualStyleBackColor = true;
            this.btnNokhod.Click += new System.EventHandler(this.btnNokhod_Click);
            // 
            // btnLobiachiti
            // 
            this.btnLobiachiti.Location = new System.Drawing.Point(183, 103);
            this.btnLobiachiti.Name = "btnLobiachiti";
            this.btnLobiachiti.Size = new System.Drawing.Size(85, 36);
            this.btnLobiachiti.TabIndex = 4;
            this.btnLobiachiti.Text = "لوبیا چیتی";
            this.btnLobiachiti.UseVisualStyleBackColor = true;
            this.btnLobiachiti.Click += new System.EventHandler(this.btnLobiachiti_Click);
            // 
            // btnBerenghashemi
            // 
            this.btnBerenghashemi.Location = new System.Drawing.Point(183, 145);
            this.btnBerenghashemi.Name = "btnBerenghashemi";
            this.btnBerenghashemi.Size = new System.Drawing.Size(85, 36);
            this.btnBerenghashemi.TabIndex = 3;
            this.btnBerenghashemi.Text = "برنج هاشمی";
            this.btnBerenghashemi.UseVisualStyleBackColor = true;
            this.btnBerenghashemi.Click += new System.EventHandler(this.btnBerenghashemi_Click);
            // 
            // btnKadoo
            // 
            this.btnKadoo.Location = new System.Drawing.Point(92, 19);
            this.btnKadoo.Name = "btnKadoo";
            this.btnKadoo.Size = new System.Drawing.Size(90, 36);
            this.btnKadoo.TabIndex = 2;
            this.btnKadoo.Text = "تخمه کدو";
            this.btnKadoo.UseVisualStyleBackColor = true;
            this.btnKadoo.Click += new System.EventHandler(this.btnKadoo_Click);
            // 
            // btnJaponi
            // 
            this.btnJaponi.Location = new System.Drawing.Point(6, 19);
            this.btnJaponi.Name = "btnJaponi";
            this.btnJaponi.Size = new System.Drawing.Size(85, 36);
            this.btnJaponi.TabIndex = 1;
            this.btnJaponi.Text = "تخمه ژاپنی";
            this.btnJaponi.UseVisualStyleBackColor = true;
            this.btnJaponi.Click += new System.EventHandler(this.btnJaponi_Click);
            // 
            // btnTokhmehSiah
            // 
            this.btnTokhmehSiah.Location = new System.Drawing.Point(183, 19);
            this.btnTokhmehSiah.Name = "btnTokhmehSiah";
            this.btnTokhmehSiah.Size = new System.Drawing.Size(85, 36);
            this.btnTokhmehSiah.TabIndex = 0;
            this.btnTokhmehSiah.Text = "تخمه سیاه";
            this.btnTokhmehSiah.UseVisualStyleBackColor = true;
            this.btnTokhmehSiah.Click += new System.EventHandler(this.btnTokhmehSiah_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnJambon);
            this.tabPage2.Controls.Add(this.btnKalbasgharch);
            this.tabPage2.Controls.Add(this.btnKalbaskhoshk);
            this.tabPage2.Controls.Add(this.btnKalbasgoosht);
            this.tabPage2.Controls.Add(this.btnKalbaspeste);
            this.tabPage2.Controls.Add(this.btnKoktel);
            this.tabPage2.Controls.Add(this.btnNanrejimi);
            this.tabPage2.Controls.Add(this.btnNansnak);
            this.tabPage2.Controls.Add(this.btnNankhoshk);
            this.tabPage2.Controls.Add(this.btnNanbaget);
            this.tabPage2.Controls.Add(this.btnMinibaget);
            this.tabPage2.Controls.Add(this.btnKhoshkehboland);
            this.tabPage2.Controls.Add(this.btnMarta);
            this.tabPage2.Controls.Add(this.btnKalbasmorgh);
            this.tabPage2.Controls.Add(this.btnSosis);
            this.tabPage2.Controls.Add(this.btnNanmahali);
            this.tabPage2.Controls.Add(this.btnNanlavash);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(278, 274);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "گروه1";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnJambon
            // 
            this.btnJambon.Location = new System.Drawing.Point(99, 222);
            this.btnJambon.Name = "btnJambon";
            this.btnJambon.Size = new System.Drawing.Size(85, 36);
            this.btnJambon.TabIndex = 18;
            this.btnJambon.Text = "ژامبون";
            this.btnJambon.UseVisualStyleBackColor = true;
            // 
            // btnKalbasgharch
            // 
            this.btnKalbasgharch.Location = new System.Drawing.Point(99, 179);
            this.btnKalbasgharch.Name = "btnKalbasgharch";
            this.btnKalbasgharch.Size = new System.Drawing.Size(85, 36);
            this.btnKalbasgharch.TabIndex = 17;
            this.btnKalbasgharch.Text = "کالباس قارچ";
            this.btnKalbasgharch.UseVisualStyleBackColor = true;
            // 
            // btnKalbaskhoshk
            // 
            this.btnKalbaskhoshk.Location = new System.Drawing.Point(99, 135);
            this.btnKalbaskhoshk.Name = "btnKalbaskhoshk";
            this.btnKalbaskhoshk.Size = new System.Drawing.Size(85, 36);
            this.btnKalbaskhoshk.TabIndex = 16;
            this.btnKalbaskhoshk.Text = "کالباس خشک";
            this.btnKalbaskhoshk.UseVisualStyleBackColor = true;
            // 
            // btnKalbasgoosht
            // 
            this.btnKalbasgoosht.Location = new System.Drawing.Point(8, 135);
            this.btnKalbasgoosht.Name = "btnKalbasgoosht";
            this.btnKalbasgoosht.Size = new System.Drawing.Size(85, 36);
            this.btnKalbasgoosht.TabIndex = 15;
            this.btnKalbasgoosht.Text = "کالباس گوشت";
            this.btnKalbasgoosht.UseVisualStyleBackColor = true;
            this.btnKalbasgoosht.Click += new System.EventHandler(this.button35_Click);
            // 
            // btnKalbaspeste
            // 
            this.btnKalbaspeste.Location = new System.Drawing.Point(8, 179);
            this.btnKalbaspeste.Name = "btnKalbaspeste";
            this.btnKalbaspeste.Size = new System.Drawing.Size(85, 36);
            this.btnKalbaspeste.TabIndex = 14;
            this.btnKalbaspeste.Text = "کالباس پسته";
            this.btnKalbaspeste.UseVisualStyleBackColor = true;
            // 
            // btnKoktel
            // 
            this.btnKoktel.Location = new System.Drawing.Point(8, 222);
            this.btnKoktel.Name = "btnKoktel";
            this.btnKoktel.Size = new System.Drawing.Size(85, 36);
            this.btnKoktel.TabIndex = 13;
            this.btnKoktel.Text = "کوکتل";
            this.btnKoktel.UseVisualStyleBackColor = true;
            // 
            // btnNanrejimi
            // 
            this.btnNanrejimi.Location = new System.Drawing.Point(99, 93);
            this.btnNanrejimi.Name = "btnNanrejimi";
            this.btnNanrejimi.Size = new System.Drawing.Size(85, 36);
            this.btnNanrejimi.TabIndex = 12;
            this.btnNanrejimi.Text = "نان رژیمی";
            this.btnNanrejimi.UseVisualStyleBackColor = true;
            // 
            // btnNansnak
            // 
            this.btnNansnak.Location = new System.Drawing.Point(187, 48);
            this.btnNansnak.Name = "btnNansnak";
            this.btnNansnak.Size = new System.Drawing.Size(85, 36);
            this.btnNansnak.TabIndex = 11;
            this.btnNansnak.Text = "نان اسنک";
            this.btnNansnak.UseVisualStyleBackColor = true;
            // 
            // btnNankhoshk
            // 
            this.btnNankhoshk.Location = new System.Drawing.Point(187, 93);
            this.btnNankhoshk.Name = "btnNankhoshk";
            this.btnNankhoshk.Size = new System.Drawing.Size(85, 36);
            this.btnNankhoshk.TabIndex = 10;
            this.btnNankhoshk.Text = "نان خشکه";
            this.btnNankhoshk.UseVisualStyleBackColor = true;
            // 
            // btnNanbaget
            // 
            this.btnNanbaget.Location = new System.Drawing.Point(99, 48);
            this.btnNanbaget.Name = "btnNanbaget";
            this.btnNanbaget.Size = new System.Drawing.Size(85, 36);
            this.btnNanbaget.TabIndex = 9;
            this.btnNanbaget.Text = "نان باگت";
            this.btnNanbaget.UseVisualStyleBackColor = true;
            // 
            // btnMinibaget
            // 
            this.btnMinibaget.Location = new System.Drawing.Point(8, 48);
            this.btnMinibaget.Name = "btnMinibaget";
            this.btnMinibaget.Size = new System.Drawing.Size(85, 36);
            this.btnMinibaget.TabIndex = 8;
            this.btnMinibaget.Text = "مینی باگت";
            this.btnMinibaget.UseVisualStyleBackColor = true;
            // 
            // btnKhoshkehboland
            // 
            this.btnKhoshkehboland.Location = new System.Drawing.Point(8, 93);
            this.btnKhoshkehboland.Name = "btnKhoshkehboland";
            this.btnKhoshkehboland.Size = new System.Drawing.Size(85, 36);
            this.btnKhoshkehboland.TabIndex = 7;
            this.btnKhoshkehboland.Text = "خشکه بلند";
            this.btnKhoshkehboland.UseVisualStyleBackColor = true;
            // 
            // btnMarta
            // 
            this.btnMarta.Location = new System.Drawing.Point(187, 135);
            this.btnMarta.Name = "btnMarta";
            this.btnMarta.Size = new System.Drawing.Size(85, 36);
            this.btnMarta.TabIndex = 6;
            this.btnMarta.Text = "کالباس مارتا";
            this.btnMarta.UseVisualStyleBackColor = true;
            // 
            // btnKalbasmorgh
            // 
            this.btnKalbasmorgh.Location = new System.Drawing.Point(187, 179);
            this.btnKalbasmorgh.Name = "btnKalbasmorgh";
            this.btnKalbasmorgh.Size = new System.Drawing.Size(85, 36);
            this.btnKalbasmorgh.TabIndex = 5;
            this.btnKalbasmorgh.Text = "کالباس مرغ";
            this.btnKalbasmorgh.UseVisualStyleBackColor = true;
            // 
            // btnSosis
            // 
            this.btnSosis.Location = new System.Drawing.Point(187, 222);
            this.btnSosis.Name = "btnSosis";
            this.btnSosis.Size = new System.Drawing.Size(85, 36);
            this.btnSosis.TabIndex = 4;
            this.btnSosis.Text = "سوسیس آلمانی";
            this.btnSosis.UseVisualStyleBackColor = true;
            // 
            // btnNanmahali
            // 
            this.btnNanmahali.Location = new System.Drawing.Point(8, 6);
            this.btnNanmahali.Name = "btnNanmahali";
            this.btnNanmahali.Size = new System.Drawing.Size(85, 36);
            this.btnNanmahali.TabIndex = 3;
            this.btnNanmahali.Text = "نان محلی";
            this.btnNanmahali.UseVisualStyleBackColor = true;
            // 
            // btnNanlavash
            // 
            this.btnNanlavash.Location = new System.Drawing.Point(99, 6);
            this.btnNanlavash.Name = "btnNanlavash";
            this.btnNanlavash.Size = new System.Drawing.Size(85, 36);
            this.btnNanlavash.TabIndex = 2;
            this.btnNanlavash.Text = "نان لواش";
            this.btnNanlavash.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(187, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 36);
            this.button2.TabIndex = 1;
            this.button2.Text = "نان تنوری";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.button39);
            this.tabPage3.Controls.Add(this.button40);
            this.tabPage3.Controls.Add(this.button41);
            this.tabPage3.Controls.Add(this.button42);
            this.tabPage3.Controls.Add(this.button43);
            this.tabPage3.Controls.Add(this.button44);
            this.tabPage3.Controls.Add(this.button45);
            this.tabPage3.Controls.Add(this.button46);
            this.tabPage3.Controls.Add(this.button47);
            this.tabPage3.Controls.Add(this.button48);
            this.tabPage3.Controls.Add(this.button49);
            this.tabPage3.Controls.Add(this.button50);
            this.tabPage3.Controls.Add(this.button51);
            this.tabPage3.Controls.Add(this.button52);
            this.tabPage3.Controls.Add(this.button53);
            this.tabPage3.Controls.Add(this.button54);
            this.tabPage3.Controls.Add(this.button55);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(278, 274);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "گروه2";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(97, 227);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(85, 36);
            this.button3.TabIndex = 36;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(97, 184);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(85, 36);
            this.button39.TabIndex = 35;
            this.button39.Text = "button39";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(99, 140);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(85, 36);
            this.button40.TabIndex = 34;
            this.button40.Text = "button40";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(8, 140);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(85, 36);
            this.button41.TabIndex = 33;
            this.button41.Text = "button41";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(8, 184);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(85, 36);
            this.button42.TabIndex = 32;
            this.button42.Text = "button42";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(8, 227);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(85, 36);
            this.button43.TabIndex = 31;
            this.button43.Text = "button43";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(99, 98);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(85, 36);
            this.button44.TabIndex = 30;
            this.button44.Text = "button44";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(187, 53);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(85, 36);
            this.button45.TabIndex = 29;
            this.button45.Text = "button45";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(187, 98);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(85, 36);
            this.button46.TabIndex = 28;
            this.button46.Text = "button46";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(97, 53);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(85, 36);
            this.button47.TabIndex = 27;
            this.button47.Text = "button47";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(8, 53);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(85, 36);
            this.button48.TabIndex = 26;
            this.button48.Text = "button48";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(8, 98);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(85, 36);
            this.button49.TabIndex = 25;
            this.button49.Text = "button49";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(187, 140);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(85, 36);
            this.button50.TabIndex = 24;
            this.button50.Text = "button50";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(187, 184);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(85, 36);
            this.button51.TabIndex = 23;
            this.button51.Text = "button51";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(187, 227);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(85, 36);
            this.button52.TabIndex = 22;
            this.button52.Text = "button52";
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(6, 11);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(85, 36);
            this.button53.TabIndex = 21;
            this.button53.Text = "button53";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(96, 11);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(85, 36);
            this.button54.TabIndex = 20;
            this.button54.Text = "button54";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(187, 11);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(85, 36);
            this.button55.TabIndex = 19;
            this.button55.Text = "button55";
            this.button55.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.btnMashinHesab);
            this.groupBox10.Controls.Add(this.btnTarazoo);
            this.groupBox10.Controls.Add(this.btnKharidSarie);
            this.groupBox10.Controls.Add(this.btnSaveFactor);
            this.groupBox10.Controls.Add(this.groupBox11);
            this.groupBox10.Controls.Add(this.groupBox12);
            this.groupBox10.Location = new System.Drawing.Point(12, 75);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(294, 228);
            this.groupBox10.TabIndex = 9;
            this.groupBox10.TabStop = false;
            // 
            // btnMashinHesab
            // 
            this.btnMashinHesab.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnMashinHesab.Image = global::Market.Properties.Resources.thin_0417_calculator;
            this.btnMashinHesab.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMashinHesab.Location = new System.Drawing.Point(200, 156);
            this.btnMashinHesab.Name = "btnMashinHesab";
            this.btnMashinHesab.Size = new System.Drawing.Size(88, 67);
            this.btnMashinHesab.TabIndex = 14;
            this.btnMashinHesab.Text = "ماشین حساب";
            this.btnMashinHesab.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMashinHesab.UseVisualStyleBackColor = true;
            this.btnMashinHesab.Click += new System.EventHandler(this.btnMashinHesab_Click);
            // 
            // btnTarazoo
            // 
            this.btnTarazoo.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnTarazoo.Image = global::Market.Properties.Resources.thin_0894_scale_weight_kitchen_appliances;
            this.btnTarazoo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnTarazoo.Location = new System.Drawing.Point(6, 83);
            this.btnTarazoo.Name = "btnTarazoo";
            this.btnTarazoo.Size = new System.Drawing.Size(92, 67);
            this.btnTarazoo.TabIndex = 13;
            this.btnTarazoo.Text = "ترازو";
            this.btnTarazoo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnTarazoo.UseVisualStyleBackColor = true;
            // 
            // btnKharidSarie
            // 
            this.btnKharidSarie.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnKharidSarie.Image = global::Market.Properties.Resources.thin_0409_wallet_credit_card_money_payment;
            this.btnKharidSarie.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnKharidSarie.Location = new System.Drawing.Point(104, 83);
            this.btnKharidSarie.Name = "btnKharidSarie";
            this.btnKharidSarie.Size = new System.Drawing.Size(90, 67);
            this.btnKharidSarie.TabIndex = 12;
            this.btnKharidSarie.Text = "خرید سریع";
            this.btnKharidSarie.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnKharidSarie.UseVisualStyleBackColor = true;
            this.btnKharidSarie.Click += new System.EventHandler(this.btnKharidSarie_Click);
            // 
            // btnSaveFactor
            // 
            this.btnSaveFactor.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSaveFactor.Image = global::Market.Properties.Resources.thin_0440_shopping_cart_basket_store;
            this.btnSaveFactor.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSaveFactor.Location = new System.Drawing.Point(200, 83);
            this.btnSaveFactor.Name = "btnSaveFactor";
            this.btnSaveFactor.Size = new System.Drawing.Size(88, 67);
            this.btnSaveFactor.TabIndex = 11;
            this.btnSaveFactor.Text = "نمایش فاکتور";
            this.btnSaveFactor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSaveFactor.UseVisualStyleBackColor = true;
            this.btnSaveFactor.Click += new System.EventHandler(this.btnSaveFactor_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Location = new System.Drawing.Point(305, 0);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(309, 228);
            this.groupBox11.TabIndex = 9;
            this.groupBox11.TabStop = false;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.txtBarcodeDisplay);
            this.groupBox12.Location = new System.Drawing.Point(6, 11);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(282, 66);
            this.groupBox12.TabIndex = 10;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "بارکد";
            // 
            // txtBarcodeDisplay
            // 
            this.txtBarcodeDisplay.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txtBarcodeDisplay.Font = new System.Drawing.Font("B Ferdosi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtBarcodeDisplay.Location = new System.Drawing.Point(12, 18);
            this.txtBarcodeDisplay.Name = "txtBarcodeDisplay";
            this.txtBarcodeDisplay.Size = new System.Drawing.Size(262, 37);
            this.txtBarcodeDisplay.TabIndex = 0;
            this.txtBarcodeDisplay.TabStop = false;
            this.txtBarcodeDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBarcodeDisplay.Click += new System.EventHandler(this.txtBarcodeDisplay_Click);
            this.txtBarcodeDisplay.TextChanged += new System.EventHandler(this.txtBarcodeDisplay_TextChanged);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.btnAddn);
            this.groupBox13.Controls.Add(this.btn00n);
            this.groupBox13.Controls.Add(this.btn000n);
            this.groupBox13.Controls.Add(this.btn9n);
            this.groupBox13.Controls.Add(this.btn7n);
            this.groupBox13.Controls.Add(this.btn0n);
            this.groupBox13.Controls.Add(this.btn8n);
            this.groupBox13.Controls.Add(this.btn6n);
            this.groupBox13.Controls.Add(this.btn4n);
            this.groupBox13.Controls.Add(this.btn5n);
            this.groupBox13.Controls.Add(this.btn3n);
            this.groupBox13.Controls.Add(this.btn1n);
            this.groupBox13.Controls.Add(this.btn2n);
            this.groupBox13.Controls.Add(this.btnNewInvoice);
            this.groupBox13.Controls.Add(this.btnSaveInvoice);
            this.groupBox13.Controls.Add(this.btnDeleteItem);
            this.groupBox13.Controls.Add(this.btnAddItem);
            this.groupBox13.Location = new System.Drawing.Point(314, 309);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(393, 341);
            this.groupBox13.TabIndex = 10;
            this.groupBox13.TabStop = false;
            // 
            // btnAddn
            // 
            this.btnAddn.Location = new System.Drawing.Point(274, 53);
            this.btnAddn.Name = "btnAddn";
            this.btnAddn.Size = new System.Drawing.Size(75, 109);
            this.btnAddn.TabIndex = 16;
            this.btnAddn.Text = "add";
            this.btnAddn.UseVisualStyleBackColor = true;
            this.btnAddn.Click += new System.EventHandler(this.btnAddn_Click);
            // 
            // btn00n
            // 
            this.btn00n.Location = new System.Drawing.Point(114, 168);
            this.btn00n.Name = "btn00n";
            this.btn00n.Size = new System.Drawing.Size(54, 46);
            this.btn00n.TabIndex = 15;
            this.btn00n.Text = "00";
            this.btn00n.UseVisualStyleBackColor = true;
            this.btn00n.Click += new System.EventHandler(this.btn00n_Click);
            // 
            // btn000n
            // 
            this.btn000n.Location = new System.Drawing.Point(184, 169);
            this.btn000n.Name = "btn000n";
            this.btn000n.Size = new System.Drawing.Size(54, 45);
            this.btn000n.TabIndex = 14;
            this.btn000n.Text = "000";
            this.btn000n.UseVisualStyleBackColor = true;
            this.btn000n.Click += new System.EventHandler(this.btn000n_Click);
            // 
            // btn9n
            // 
            this.btn9n.Location = new System.Drawing.Point(184, 117);
            this.btn9n.Name = "btn9n";
            this.btn9n.Size = new System.Drawing.Size(54, 46);
            this.btn9n.TabIndex = 13;
            this.btn9n.Text = "9";
            this.btn9n.UseVisualStyleBackColor = true;
            this.btn9n.Click += new System.EventHandler(this.btn9n_Click);
            // 
            // btn7n
            // 
            this.btn7n.Location = new System.Drawing.Point(44, 116);
            this.btn7n.Name = "btn7n";
            this.btn7n.Size = new System.Drawing.Size(55, 46);
            this.btn7n.TabIndex = 12;
            this.btn7n.Text = "7";
            this.btn7n.UseVisualStyleBackColor = true;
            this.btn7n.Click += new System.EventHandler(this.btn7n_Click);
            // 
            // btn0n
            // 
            this.btn0n.Location = new System.Drawing.Point(44, 168);
            this.btn0n.Name = "btn0n";
            this.btn0n.Size = new System.Drawing.Size(55, 46);
            this.btn0n.TabIndex = 11;
            this.btn0n.Text = "0";
            this.btn0n.UseVisualStyleBackColor = true;
            this.btn0n.Click += new System.EventHandler(this.btn0n_Click);
            // 
            // btn8n
            // 
            this.btn8n.Location = new System.Drawing.Point(114, 116);
            this.btn8n.Name = "btn8n";
            this.btn8n.Size = new System.Drawing.Size(54, 46);
            this.btn8n.TabIndex = 10;
            this.btn8n.Text = "8";
            this.btn8n.UseVisualStyleBackColor = true;
            this.btn8n.Click += new System.EventHandler(this.btn8n_Click);
            // 
            // btn6n
            // 
            this.btn6n.Location = new System.Drawing.Point(184, 65);
            this.btn6n.Name = "btn6n";
            this.btn6n.Size = new System.Drawing.Size(54, 46);
            this.btn6n.TabIndex = 9;
            this.btn6n.Text = "6";
            this.btn6n.UseVisualStyleBackColor = true;
            this.btn6n.Click += new System.EventHandler(this.btn6n_Click);
            // 
            // btn4n
            // 
            this.btn4n.Location = new System.Drawing.Point(44, 64);
            this.btn4n.Name = "btn4n";
            this.btn4n.Size = new System.Drawing.Size(55, 46);
            this.btn4n.TabIndex = 8;
            this.btn4n.Text = "4";
            this.btn4n.UseVisualStyleBackColor = true;
            this.btn4n.Click += new System.EventHandler(this.btn4n_Click);
            // 
            // btn5n
            // 
            this.btn5n.Location = new System.Drawing.Point(114, 65);
            this.btn5n.Name = "btn5n";
            this.btn5n.Size = new System.Drawing.Size(54, 46);
            this.btn5n.TabIndex = 7;
            this.btn5n.Text = "5";
            this.btn5n.UseVisualStyleBackColor = true;
            this.btn5n.Click += new System.EventHandler(this.btn5n_Click);
            // 
            // btn3n
            // 
            this.btn3n.Location = new System.Drawing.Point(184, 13);
            this.btn3n.Name = "btn3n";
            this.btn3n.Size = new System.Drawing.Size(54, 46);
            this.btn3n.TabIndex = 6;
            this.btn3n.Text = "3";
            this.btn3n.UseVisualStyleBackColor = true;
            this.btn3n.Click += new System.EventHandler(this.btn3n_Click);
            // 
            // btn1n
            // 
            this.btn1n.Location = new System.Drawing.Point(44, 13);
            this.btn1n.Name = "btn1n";
            this.btn1n.Size = new System.Drawing.Size(54, 46);
            this.btn1n.TabIndex = 5;
            this.btn1n.Text = "1";
            this.btn1n.UseVisualStyleBackColor = true;
            this.btn1n.Click += new System.EventHandler(this.btn1n_Click);
            // 
            // btn2n
            // 
            this.btn2n.Location = new System.Drawing.Point(114, 13);
            this.btn2n.Name = "btn2n";
            this.btn2n.Size = new System.Drawing.Size(54, 46);
            this.btn2n.TabIndex = 4;
            this.btn2n.Text = "2";
            this.btn2n.UseVisualStyleBackColor = true;
            this.btn2n.Click += new System.EventHandler(this.btn2n_Click);
            // 
            // btnNewInvoice
            // 
            this.btnNewInvoice.Image = global::Market.Properties.Resources.shopping_cart;
            this.btnNewInvoice.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnNewInvoice.Location = new System.Drawing.Point(8, 225);
            this.btnNewInvoice.Name = "btnNewInvoice";
            this.btnNewInvoice.Size = new System.Drawing.Size(91, 102);
            this.btnNewInvoice.TabIndex = 3;
            this.btnNewInvoice.Text = "فاکتور جدید";
            this.btnNewInvoice.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNewInvoice.UseVisualStyleBackColor = true;
            this.btnNewInvoice.Click += new System.EventHandler(this.btnNewInvoice_Click);
            // 
            // btnSaveInvoice
            // 
            this.btnSaveInvoice.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSaveInvoice.Image = global::Market.Properties.Resources.thin_0440_shopping_cart_basket_store;
            this.btnSaveInvoice.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSaveInvoice.Location = new System.Drawing.Point(105, 225);
            this.btnSaveInvoice.Name = "btnSaveInvoice";
            this.btnSaveInvoice.Size = new System.Drawing.Size(89, 102);
            this.btnSaveInvoice.TabIndex = 2;
            this.btnSaveInvoice.Text = "ذخیره فاکتور";
            this.btnSaveInvoice.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSaveInvoice.UseVisualStyleBackColor = false;
            this.btnSaveInvoice.Click += new System.EventHandler(this.btnSaveInvoice_Click);
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.BackColor = System.Drawing.Color.Tomato;
            this.btnDeleteItem.Image = global::Market.Properties.Resources.delete_item1;
            this.btnDeleteItem.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDeleteItem.Location = new System.Drawing.Point(200, 225);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(90, 102);
            this.btnDeleteItem.TabIndex = 1;
            this.btnDeleteItem.Text = "حذف آیتم";
            this.btnDeleteItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDeleteItem.UseVisualStyleBackColor = false;
            this.btnDeleteItem.Click += new System.EventHandler(this.btnDeleteItem_Click);
            // 
            // btnAddItem
            // 
            this.btnAddItem.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnAddItem.ForeColor = System.Drawing.Color.Black;
            this.btnAddItem.Image = global::Market.Properties.Resources.add_item1;
            this.btnAddItem.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAddItem.Location = new System.Drawing.Point(296, 225);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(91, 102);
            this.btnAddItem.TabIndex = 0;
            this.btnAddItem.Text = "اضافه کردن آیتم";
            this.btnAddItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAddItem.UseVisualStyleBackColor = false;
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Font = new System.Drawing.Font("B Nazanin", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtCustomerName.Location = new System.Drawing.Point(722, 115);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(204, 30);
            this.txtCustomerName.TabIndex = 11;
            // 
            // lbltCustomerName
            // 
            this.lbltCustomerName.AutoSize = true;
            this.lbltCustomerName.Location = new System.Drawing.Point(728, 94);
            this.lbltCustomerName.Name = "lbltCustomerName";
            this.lbltCustomerName.Size = new System.Drawing.Size(36, 18);
            this.lbltCustomerName.TabIndex = 12;
            this.lbltCustomerName.Text = "مشتری";
            // 
            // txtProductID
            // 
            this.txtProductID.Font = new System.Drawing.Font("B Nazanin", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtProductID.Location = new System.Drawing.Point(722, 202);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.Size = new System.Drawing.Size(42, 30);
            this.txtProductID.TabIndex = 13;
            // 
            // lblProductID
            // 
            this.lblProductID.AutoSize = true;
            this.lblProductID.Location = new System.Drawing.Point(728, 178);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(18, 18);
            this.lblProductID.TabIndex = 14;
            this.lblProductID.Text = "کد";
            // 
            // txtProductName
            // 
            this.txtProductName.Font = new System.Drawing.Font("B Nazanin", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtProductName.Location = new System.Drawing.Point(770, 202);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(100, 30);
            this.txtProductName.TabIndex = 15;
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new System.Drawing.Point(782, 179);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(50, 18);
            this.lblProductName.TabIndex = 16;
            this.lblProductName.Text = "نام محصول";
            // 
            // lblQty
            // 
            this.lblQty.AutoSize = true;
            this.lblQty.Location = new System.Drawing.Point(933, 178);
            this.lblQty.Name = "lblQty";
            this.lblQty.Size = new System.Drawing.Size(28, 18);
            this.lblQty.TabIndex = 17;
            this.lblQty.Text = "تعداد";
            // 
            // txtQty
            // 
            this.txtQty.Font = new System.Drawing.Font("B Nazanin", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtQty.Location = new System.Drawing.Point(936, 202);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(86, 30);
            this.txtQty.TabIndex = 18;
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.Font = new System.Drawing.Font("B Nazanin", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtUnitPrice.Location = new System.Drawing.Point(1086, 202);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new System.Drawing.Size(100, 30);
            this.txtUnitPrice.TabIndex = 19;
            // 
            // lblUnitPrice
            // 
            this.lblUnitPrice.AutoSize = true;
            this.lblUnitPrice.Location = new System.Drawing.Point(1078, 178);
            this.lblUnitPrice.Name = "lblUnitPrice";
            this.lblUnitPrice.Size = new System.Drawing.Size(29, 18);
            this.lblUnitPrice.TabIndex = 20;
            this.lblUnitPrice.Text = "قیمت";
            // 
            // dgvInvoiceItems
            // 
            this.dgvInvoiceItems.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvInvoiceItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvInvoiceItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInvoiceItems.Location = new System.Drawing.Point(730, 239);
            this.dgvInvoiceItems.Name = "dgvInvoiceItems";
            this.dgvInvoiceItems.Size = new System.Drawing.Size(456, 289);
            this.dgvInvoiceItems.TabIndex = 21;
            // 
            // lblInvoicID
            // 
            this.lblInvoicID.AutoSize = true;
            this.lblInvoicID.Location = new System.Drawing.Point(986, 94);
            this.lblInvoicID.Name = "lblInvoicID";
            this.lblInvoicID.Size = new System.Drawing.Size(56, 18);
            this.lblInvoicID.TabIndex = 22;
            this.lblInvoicID.Text = "شماره فاکتور";
            // 
            // txtInvoicID
            // 
            this.txtInvoicID.Font = new System.Drawing.Font("B Nazanin", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtInvoicID.Location = new System.Drawing.Point(956, 115);
            this.txtInvoicID.Name = "txtInvoicID";
            this.txtInvoicID.Size = new System.Drawing.Size(229, 30);
            this.txtInvoicID.TabIndex = 23;
            // 
            // btndownT
            // 
            this.btndownT.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btndownT.Image = global::Market.Properties.Resources.down;
            this.btndownT.Location = new System.Drawing.Point(1032, 201);
            this.btndownT.Name = "btndownT";
            this.btndownT.Size = new System.Drawing.Size(50, 31);
            this.btndownT.TabIndex = 25;
            this.btndownT.UseVisualStyleBackColor = true;
            // 
            // btnupT
            // 
            this.btnupT.Image = global::Market.Properties.Resources.up;
            this.btnupT.Location = new System.Drawing.Point(876, 202);
            this.btnupT.Name = "btnupT";
            this.btnupT.Size = new System.Drawing.Size(50, 31);
            this.btnupT.TabIndex = 24;
            this.btnupT.UseVisualStyleBackColor = true;
            // 
            // FrmForoosh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1196, 658);
            this.Controls.Add(this.btndownT);
            this.Controls.Add(this.btnupT);
            this.Controls.Add(this.txtInvoicID);
            this.Controls.Add(this.lblInvoicID);
            this.Controls.Add(this.dgvInvoiceItems);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.lblUnitPrice);
            this.Controls.Add(this.txtUnitPrice);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.lblQty);
            this.Controls.Add(this.lblProductName);
            this.Controls.Add(this.txtProductName);
            this.Controls.Add(this.lblProductID);
            this.Controls.Add(this.txtProductID);
            this.Controls.Add(this.lbltCustomerName);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("B Nazanin", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmForoosh";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فروش ";
            this.Load += new System.EventHandler(this.FrmForoosh_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.btnNantanoori.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoiceItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblForooshgah;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button btnTarazoo;
        private System.Windows.Forms.Button btnKharidSarie;
        private System.Windows.Forms.Button btnSaveFactor;
        private System.Windows.Forms.Button btnMashinHesab;
        private System.Windows.Forms.TabControl btnNantanoori;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnTokhmehSiah;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtbarcodeInput;
        private System.Windows.Forms.TextBox txtbarcodeDisplay;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label lbltCustomerName;
        private System.Windows.Forms.TextBox txtProductID;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblQty;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.TextBox txtUnitPrice;
        private System.Windows.Forms.Label lblUnitPrice;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.DataGridView dgvInvoiceItems;
        private System.Windows.Forms.Button btnNewInvoice;
        private System.Windows.Forms.Button btnSaveInvoice;
        private System.Windows.Forms.Button btnDeleteItem;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.TextBox txtDiscountAmount;
        private System.Windows.Forms.Label lblDiscountAmount;
        private System.Windows.Forms.Label lbl2TotalAmount;
        private System.Windows.Forms.TextBox txtTotalAmount;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label lblInvoicID;
        private System.Windows.Forms.TextBox txtInvoicID;
        private System.Windows.Forms.Button btnNesieh;
        private System.Windows.Forms.Button btnNaghdi;
        private System.Windows.Forms.Button btnKarti;
        private System.Windows.Forms.TextBox txtNamayeshi;
        private System.Windows.Forms.Button btnErsalPeik;
        private System.Windows.Forms.Button btnZoghallimo;
        private System.Windows.Forms.Button btnZoghalbaloot;
        private System.Windows.Forms.Button btnLobiasefid;
        private System.Windows.Forms.Button btnAdas;
        private System.Windows.Forms.Button btnLobiabolboli;
        private System.Windows.Forms.Button btnBerenghendi;
        private System.Windows.Forms.Button btnBerenjanbar;
        private System.Windows.Forms.Button btnLobiaghermez;
        private System.Windows.Forms.Button btnZoghaljakson;
        private System.Windows.Forms.Button btnkakao;
        private System.Windows.Forms.Button btnGahve;
        private System.Windows.Forms.Button btnTokhmemorgh;
        private System.Windows.Forms.Button btnNokhod;
        private System.Windows.Forms.Button btnLobiachiti;
        private System.Windows.Forms.Button btnBerenghashemi;
        private System.Windows.Forms.Button btnKadoo;
        private System.Windows.Forms.Button btnJaponi;
        private System.Windows.Forms.Button btnKalbasgoosht;
        private System.Windows.Forms.Button btnKalbaspeste;
        private System.Windows.Forms.Button btnKoktel;
        private System.Windows.Forms.Button btnNanrejimi;
        private System.Windows.Forms.Button btnNansnak;
        private System.Windows.Forms.Button btnNankhoshk;
        private System.Windows.Forms.Button btnNanbaget;
        private System.Windows.Forms.Button btnMinibaget;
        private System.Windows.Forms.Button btnKhoshkehboland;
        private System.Windows.Forms.Button btnMarta;
        private System.Windows.Forms.Button btnKalbasmorgh;
        private System.Windows.Forms.Button btnSosis;
        private System.Windows.Forms.Button btnNanmahali;
        private System.Windows.Forms.Button btnNanlavash;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnJambon;
        private System.Windows.Forms.Button btnKalbasgharch;
        private System.Windows.Forms.Button btnKalbaskhoshk;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button btnupT;
        private System.Windows.Forms.Button btndownT;
        private System.Windows.Forms.Button btn2n;
        private System.Windows.Forms.Button btn000n;
        private System.Windows.Forms.Button btn9n;
        private System.Windows.Forms.Button btn7n;
        private System.Windows.Forms.Button btn0n;
        private System.Windows.Forms.Button btn8n;
        private System.Windows.Forms.Button btn6n;
        private System.Windows.Forms.Button btn4n;
        private System.Windows.Forms.Button btn5n;
        private System.Windows.Forms.Button btn3n;
        private System.Windows.Forms.Button btn1n;
        private System.Windows.Forms.Button btnAddn;
        private System.Windows.Forms.Button btn00n;
    }
}