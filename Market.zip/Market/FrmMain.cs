﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void کاربرانToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmUsers user = new FrmUsers();
            user.ShowDialog();
        }

        private void نقشهاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmRoles rols = new FrmRoles();
            rols.ShowDialog();
        }

        private void دسترسیهاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPermissions per = new FrmPermissions();
            per.ShowDialog();
        }

        private void تغییردسترسیکاربرانToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmRolePermissions rolper = new FrmRolePermissions();
            rolper.ShowDialog();
        }

        private void محصولاتToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FrmProducts product = new FrmProducts();
            product.ShowDialog();
        }

        private void شرکتهایتامینکنندهToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmSuppliers supplier = new FrmSuppliers();
            supplier.ShowDialog();
        }

        private void انبارToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmStock stock = new FrmStock();
            stock.ShowDialog();
        }

        private void فاکتورهایفروشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmSalesInvoices invoise = new FrmSalesInvoices();
            invoise.ShowDialog();
        }

        private void جزییاتفاکتورToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmSalesInvoiceItems iteminvoice = new FrmSalesInvoiceItems();
            iteminvoice.ShowDialog();
        }

        private void خروجToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
