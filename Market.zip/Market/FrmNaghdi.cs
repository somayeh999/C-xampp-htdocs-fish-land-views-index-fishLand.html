﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Market
{
    public partial class FrmNaghdi : Form
    {
        public FrmNaghdi()
        {
            InitializeComponent();
        }

        private void btnPardakht_Click(object sender, EventArgs e)
        {
            MessageBox.Show("پرداخت با موفقیت ثبت شد");
            this.Close();
        }

        private void btnFacNew_Click(object sender, EventArgs e)
        {
            txtMablagh.Text = "";
            txtMablagh.Focus();
        }
    }
}
